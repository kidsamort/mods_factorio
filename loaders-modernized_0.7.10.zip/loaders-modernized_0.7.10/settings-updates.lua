if mods["aai-loaders"] then
  data.raw["string-setting"]["aai-loaders-mode"].default_value = "graphics-only"
end
