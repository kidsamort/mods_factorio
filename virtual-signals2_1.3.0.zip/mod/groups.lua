-- Auto generated, do not edit.
-- Generated at 2024-11-02

data:extend({
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-cmn",
		  group = "signals",
		  order = "a_vs2[001]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-cmn2",
		  group = "signals",
		  order = "a_vs2[002]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-cmn3",
		  group = "signals",
		  order = "a_vs2[003]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-math",
		  group = "signals",
		  order = "a_vs2[010]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-greek",
		  group = "signals",
		  order = "a_vs2[020]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-fa",
		  group = "signals",
		  order = "a_vs2[030]"
		},
		{
		  type = "item-subgroup",
		  name = "virtual-signal-vs2-cmn_digits",
		  group = "signals",
		  order = "a_vs2[050]"
		},
})