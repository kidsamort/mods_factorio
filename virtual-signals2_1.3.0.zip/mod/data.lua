require("__virtual-signals2__.groups")
require("__virtual-signals2__.signals")