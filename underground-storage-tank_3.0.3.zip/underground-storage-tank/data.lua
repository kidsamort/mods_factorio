require("prototypes/tank")
require("prototypes/animations")
