require("__LSlib_James_Fork__/LSlib")
require("prototypes/item-groups")

Modname = "__James-Train-Mod__"

