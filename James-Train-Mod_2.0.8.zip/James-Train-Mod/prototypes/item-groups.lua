data:extend({
	{
		type = "item-subgroup",
		name = "locomotives",
		group = "logistics",
		order = "e-1",
	},
	{
		type = "item-subgroup",
		name = "wagons",
		group = "logistics",
		order = "e-1",
	},
})