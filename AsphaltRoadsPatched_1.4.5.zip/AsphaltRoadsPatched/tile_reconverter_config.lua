-- This table contains all base tiles for the reconverter can be reverted using the reconverter.
-- Every placeable tile item that contains only one of the listed base tiles can be reconverted to the corresponding base tile.
AR_reconverter_basic_ingredients = {
	["refined-concrete"] = true,
	["concrete"] = true,
	["stone-brick"] = true,
	["Arci-asphalt"] = true,
}