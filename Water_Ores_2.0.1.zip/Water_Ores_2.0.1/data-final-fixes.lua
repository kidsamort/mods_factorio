local tiles = {"deepwater","deepwater-green","water","water-green","water-mud","water-shallow","landfill"}

for _,tile in pairs(tiles) do 
    --log(tile)
    --log(serpent.block(data.raw["tile"][tile].collision_mask))
    local thistile = data.raw["tile"][tile]
    if thistile then
        local mask = data.raw["tile"][tile].collision_mask
        mask.layers["resource"] = nil -- Much easier to remove a layer now, just set it to false. No loops.
        -- If Space Age is enabled, we need to add a new collision layer to stop ice from spawning on nauvis.
        if (mods["space-age"] and thistile ~= "landfill") then
            mask.layers["nauvwater"] = true 
        end
    end
    --log(serpent.block(data.raw["tile"][tile].collision_mask))
end

if mods["space-age"] then
    data:extend{{name="nauvwater",type="collision-layer"}}
    data.raw.explosion["aquilo-tiles-inner-explosion"].created_effect.action_delivery.target_effects[1].tile_collision_mask.layers["nauvwater"] = true
    data.raw.explosion["aquilo-tiles-outer-explosion"].created_effect.action_delivery.target_effects[1].tile_collision_mask.layers["nauvwater"] = true
    data.raw.explosion["aquilo-tiles-outer-explosion"].created_effect.action_delivery.target_effects[2].tile_collision_mask.layers["nauvwater"] = true
end