
if not LSlib.technology then require "technology" else

function LSlib.technology.removeRecipeUnlock(technologyName, recipeToRemove)
    if not data.raw.technology[technologyName] or not data.raw.recipe[recipeName] then return end
		if data.raw["technology"][technologyName].effects then
			for index, effect in pairs(data.raw["technology"][technologyName].effects) do
				if effect.type == "unlock-recipe" and effect.recipe == recipeName then
					table.remove(data.raw["technology"][technologyName].effects, index)
					if table_size(data.raw["technology"][technologyName].effects) == 0 then
					  data.raw["technology"][technologyName].effects = nil
					end
					break
				end
			end
		end
	end
end



function LSlib.technology.addRecipeUnlock(technologyName, recipeToAdd)
    if not data.raw.technology[technologyName] or not data.raw.recipe[recipeName] then return end
	if not data.raw["technology"][technologyName].effects then
        data.raw["technology"][technologyName].effects = {}
	end
	for _, effect in pairs(data.raw["technology"][technologyName].effects) do
		if effect.type == "unlock-recipe" and effect.recipe == recipeName then return end
	end
	table.insert(data.raw["technology"][technologyName].effects, {type = "unlock-recipe", recipe = recipeName})
end



function LSlib.technology.moveRecipeUnlock(oldTechnologyName, newTechnologyName, recipeToMove)
    if not data.raw["technology"][newTechnologyName] then
		LSlib.technology.removeRecipeUnlock(oldTechnologyName, recipeToMove)
		return
    end

    if data.raw["technology"][oldTechnologyName] then
      local removed = false
      for index, effect in pairs(data.raw["technology"][oldTechnologyName].effects) do
        if effect.type == "unlock-recipe" and effect.recipe == recipeToMove then
          table.remove(data.raw["technology"][oldTechnologyName].effects, index)
          removed = true
          break
        end
      end
	end
    LSlib.technology.addRecipeUnlock(newTechnologyName, recipeToMove)
end