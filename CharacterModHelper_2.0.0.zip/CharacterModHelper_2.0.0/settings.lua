
-- Startup settings
data:extend({
  {
    name = "CMH_debugging",
    type = "bool-setting",
    setting_type = "startup",
    default_value = true,
    order = "a[debugging]",
  },
})
