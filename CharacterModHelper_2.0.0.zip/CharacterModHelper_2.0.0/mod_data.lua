-- Settings for calling Pi-C_lib
return {
  mod_name = "CharacterModHelper",
  mod_shortname = "CMH",
  debug_log_setting = "CMH_debugging",
  debug_log_setting_type = "startup",
  debug_game_setting = nil,
  debug_game_setting_type = nil,
}
