local HIT_EFFECTS = require("__base__/prototypes/entity/hit-effects")
local GRAPHICS_PATH = "__k2-wind-turbine__/graphics/"
local SOUNDS_PATH = "__k2-wind-turbine__/sounds/"

local sounds = {
    variations = {
        {filename = SOUNDS_PATH .. "wind-turbine-rotating.ogg", volume = 0.55},
        {filename = SOUNDS_PATH .. "wind-turbine-rotating-2.ogg", volume = 0.38}
    },
    aggregation = {max_count = 3, remove = false, count_already_playing = true}
}

data:extend({
    {
        type = "item",
        name = "k2-wind-turbine",
        icon = GRAPHICS_PATH .. "icons/k2-wind-turbine.png",
        icon_size = 64,
        subgroup = "energy",
        stack_size = 50,
        place_result = "k2-wind-turbine"
    },
    {
        type = "recipe",
        name = "k2-wind-turbine",
        energy_required = 5,
        ingredients = {
            {type = "item", name = "iron-plate", amount = 9},
            {type = "item", name = "stone-brick", amount = 8},
            {type = "item", name = "iron-gear-wheel", amount = 6},
            {type = "item", name = "copper-cable", amount = 6},
        },
        results = {
            {type = "item", name = "k2-wind-turbine", amount = 1}
        }
    },
    {
        type = "electric-energy-interface",
        name = "k2-wind-turbine",
        icon = GRAPHICS_PATH .. "icons/k2-wind-turbine.png",
        icon_size = 64,
        flags = {"placeable-neutral", "player-creation", "not-rotatable"},
        minable = {mining_time = 0.25, result = "k2-wind-turbine"},
        max_health = 200,
        corpse = "medium-remnants",
        resistances = {
            {type = "fire", percent = 30},
            {type = "physical", percent = 60},
            {type = "impact", percent = 30}
        },
        damaged_trigger_effect = HIT_EFFECTS.entity(),
        collision_box = {{-1.25, -1.25}, {1.25, 1.25}},
        selection_box = {{-1.45, -1.45}, {1.45, 1.45}},
        drawing_box = {{-0.5, -2}, {0.5, 1}},
        energy_source = {
            type = "electric",
            buffer_capacity = "100kJ",
            usage_priority = "primary-output",
            output_flow_limit = settings.startup["k2-wind-turbine-output"].value,
            render_no_power_icon = false,
        },
        water_reflection = {
            pictures = {
                filename = GRAPHICS_PATH .. "entities/wind-turbine-reflection.png",
                priority = "extra-high",
                width = 20,
                height = 25,
                shift = util.by_pixel(0, 40),
                variation_count = 1,
                scale = 5,
            },
            rotate = false,
            orientation_to_variation = false
        },
        energy_production = settings.startup["k2-wind-turbine-output"].value,
        animation = {
            layers = {
                {
                    filename = GRAPHICS_PATH .. "entities/wind-turbine.png",
                    priority = "high",
                    width = 98,
                    height = 143,
                    frame_count = 30,
                    line_length = 6,
                    animation_speed = 0.8,
                    shift = {0, -1.2},
                    hr_version = {
                        filename = GRAPHICS_PATH .. "entities/hr-wind-turbine.png",
                        priority = "medium",
                        width = 196,
                        height = 286,
                        scale = 0.5,
                        frame_count = 30,
                        line_length = 6,
                        animation_speed = 0.8,
                        shift = {0, -1.2},
                    },
                },
                {
                    filename = GRAPHICS_PATH .. "entities/wind-turbine-shadow.png",
                    priority = "high",
                    width = 121,
                    height = 50,
                    frame_count = 30,
                    line_length = 6,
                    scale = 1.3,
                    animation_speed = 0.5,
                    draw_as_shadow = true,
                    shift = {1.15, 0.05},
                    hr_version = {
                        filename = GRAPHICS_PATH .. "entities/hr-wind-turbine-shadow.png",
                        priority = "medium",
                        width = 242,
                        height = 100,
                        scale = 0.65,
                        frame_count = 30,
                        line_length = 6,
                        animation_speed = 0.5,
                        draw_as_shadow = true,
                        shift = {1.15, 0.05},
                    },
                },
            },
        },
        continuous_animation = true,
        working_sound = {
            sound = sounds,
            idle_sound = sounds,
            persistent = true,
        }
    }
})