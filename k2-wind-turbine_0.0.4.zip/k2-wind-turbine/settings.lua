data:extend({
    {
        type = "string-setting",
        name = "k2-wind-turbine-output",
        setting_type = "startup",
        default_value = "20kW",
        allowed_values = {"20kW", "40kW", "120kW", "250kW", "500kW", "1MW"}
    }
})