data:extend{
  {
      type = "bool-setting",
      name = "informatron-show-overhead-button",
      setting_type = "runtime-per-user",
      default_value = true,
  },
  {
      type = "bool-setting",
      name = "informatron-show-at-start",
      setting_type = "runtime-per-user",
      default_value = true,
  }
}
