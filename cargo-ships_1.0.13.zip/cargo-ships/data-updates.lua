require("__cargo-ships__/constants")
require("__cargo-ships__/prototypes/resources-new")
