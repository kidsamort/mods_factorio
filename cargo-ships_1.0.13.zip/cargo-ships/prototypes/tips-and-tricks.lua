data:extend{
  {
    type = "tips-and-tricks-item-category",
    name = "cargo-ships",
    order = "fa-[cargo-ships]",
  },
  {
    type = "tips-and-tricks-item",
    name = "cargo-ships",
    category = "cargo-ships",
    is_title = true,
    order = "a",
    image = "__cargo-ships-graphics__/assets/shortcut-tutorial.png"
  },
}