math2d = require("math2d")

require("__cargo-ships__/constants")
require("__cargo-ships__/prototypes/entity")
require("__cargo-ships__/prototypes/item")
require("__cargo-ships__/prototypes/recipe")
require("__cargo-ships__/prototypes/technologies")
require("__cargo-ships__/prototypes/tips-and-tricks")
require("__cargo-ships__/input/input")
