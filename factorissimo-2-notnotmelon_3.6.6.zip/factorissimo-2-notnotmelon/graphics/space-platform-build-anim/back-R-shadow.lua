return
{
  width = 174,
  height = 84,
  shift = util.by_pixel( 26.0, 0.5),
  line_length = 8,
}
