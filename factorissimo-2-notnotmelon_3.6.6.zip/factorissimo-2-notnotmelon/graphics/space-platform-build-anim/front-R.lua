return
{
  width = 78,
  height = 164,
  shift = util.by_pixel( 3.0, -17.5),
  line_length = 8,
}
