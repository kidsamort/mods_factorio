return
{
  width = 76,
  height = 96,
  shift = util.by_pixel( -3.0, -30.0),
  line_length = 8,
}
