return
{
  width = 188,
  height = 84,
  shift = util.by_pixel( 28.5, 0.5),
  line_length = 8,
}
