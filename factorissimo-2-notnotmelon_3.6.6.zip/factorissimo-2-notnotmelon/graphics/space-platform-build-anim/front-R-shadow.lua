return
{
  width = 172,
  height = 88,
  shift = util.by_pixel( 25.5, 1.0),
  line_length = 8,
}
