local surface = game.get_surface("factory-power-connection")
if surface then game.delete_surface(surface) end
