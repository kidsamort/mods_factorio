minime.entered_file()

-- Make versions of characters from skin-changing mods for Bob's classes
if mods["bobclasses"] then
  require("prototypes.2-bob_classes")
end

minime.entered_file("leave")
