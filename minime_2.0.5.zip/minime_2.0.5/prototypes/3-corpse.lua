minime.entered_file()
------------------------------------------------------------------------------------

-- Generic corpse should have the same order string as the default corpse
local corpses   = data.raw["character-corpse"]
local default   = corpses["character-corpse"]
local generic   = data.raw["character-corpse"][minime.modName .. "_generic_corpse"]

generic.order   = default.order
minime.writeDebug("Changed order of %s to %s",
                  {minime.argprint(generic), minime.argprint(generic.order)})

------------------------------------------------------------------------------------
minime.entered_file("leave")
