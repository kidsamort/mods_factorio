minime.entered_file()

if not minime.character_selector then
  minime.entered_file("leave", "character selector is not active")
  return
end

------------------------------------------------------------------------------------
-- Define sprites
------------------------------------------------------------------------------------

-- Toggle button (character selector)
local sprites = {
  button = {
    type = "sprite",
    name = minime.sprite_names["button"],
    filename = minime.IMG_PATH.."gui-toggle-button-dark-64.png",
    priority = "extra-high-no-scale",
    flags = { "gui-icon", },
    size = 64,
  },

  shortcut = {
    type = "sprite",
    name = minime.sprite_names["shortcut"],
    filename = minime.IMG_PATH.."gui-toggle-shortcut-dark-32.png",
    priority = "extra-high-no-scale",
    flags = { "icon", },
    size = 32,
    --~ mipmap_count = 2,
  },

  shortcut_small = {
    type = "sprite",
    name = minime.sprite_names["shortcut_small"],
    filename = minime.IMG_PATH.."gui-toggle-shortcut-dark-24.png",
    priority = "extra-high-no-scale",
    flags = { "icon", },
    size = 24,
    --~ mipmap_count = 2,
  },

  shortcut_disabled = {
    type = "sprite",
    name = minime.sprite_names["shortcut_disabled"],
    filename = minime.IMG_PATH.."gui-toggle-shortcut-light-32.png",
    priority = "extra-high-no-scale",
    flags = { "icon", },
    size = 32,
    --~ mipmap_count = 2,
  },

  shortcut_small_disabled = {
    type = "sprite",
    name = minime.sprite_names["shortcut_small_disabled"],
    filename = minime.IMG_PATH.."gui-toggle-shortcut-light-24.png",
    priority = "extra-high-no-scale",
    flags = { "icon", },
    size = 24,
    --~ mipmap_count = 2,
  },
}

for s_name, sprite in pairs(sprites) do
  data:extend({sprite})
  minime.created_msg(sprite)
end

------------------------------------------------------------------------------------
minime.entered_file("leave")
