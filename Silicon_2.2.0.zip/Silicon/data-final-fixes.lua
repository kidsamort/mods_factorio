local stack_size = settings.startup['stack_size'].value
for _,dat in pairs(data.raw,item) do
	for _,items in pairs(dat) do
		if
			items.stack_size and items.stack_size > 1 then
			items.stack_size = stack_size
			data.raw.item["nuclear-fuel"].stack_size = stack_size
		end
	end
end