local module_settings = {"productivity"}
local module_default = "none"
if mods["quality"] then
	table.insert(module_settings,"quality")
	table.insert(module_settings,"both")
	module_default = "quality"
end
table.insert(module_settings,"none")

data:extend({
	{
		type = "bool-setting",
		name = "rf-solid-fluids",
		setting_type = "startup",
		default_value = true,
		order = "a"
	},
	{
		type = "string-setting",
		name = "rf-balance",
		setting_type = "startup",
		default_value = "vanilla",
		allowed_values = {"vanilla","no balance","user defined"},
		order = "a-a"
	},
	{
		type = "int-setting",
		name = "rf-efficiency",
		setting_type = "startup",
		default_value = 25,
		minimum_value = 1,
		maximum_value = 100,
		order = "a-b"
	},
	{
		type = "bool-setting",
		name = "rf-intermediates",
		setting_type = "startup",
		default_value = true,
		order = "a-c"
	},
	{
		type = "string-setting",
		name = "rf-modules",
		setting_type = "startup",
		default_value = module_default,
		allowed_values = module_settings,
		order = "a-d"
	},
	{
		type = "bool-setting",
		name = "rf-revert-modules",
		setting_type = "startup",
		default_value = false,
		order = "a-e"
	},
	{
		type = "bool-setting",
		name = "rf-autopush",
		setting_type = "runtime-global",
		default_value = true,
		order = "c-a"
	},
	{
		type = "int-setting",
		name = "rf-delay",
		setting_type = "runtime-global",
		default_value = 30,
		minimum_value = 5,
		maximum_value = 300,
		order = "c-b"
	},
	{
		type = "int-setting",
		name = "rf-timer",
		setting_type = "runtime-global",
		default_value = 90,
		minimum_value = 10,
		maximum_value = 600,
		order = "c-c"
	}
})

if mods["space-age"] then
data:extend({
	{
		type = "string-setting",
		name = "rf-craft-limit",
		setting_type = "startup",
		default_value = "nauvis",
		allowed_values = {"nauvis","nauvis, gleba","nauvis, gleba, aquilo", "nauvis, gleba, vulcanus", "nauvis, gleba, aquilo, vulcanus","all planets", "no restrictions"},
		order = "b-a"
	},
	{
		type = "string-setting",
		name = "rf-place-limit",
		setting_type = "startup",
		default_value = "nauvis, gleba, aquilo",
		allowed_values = {"nauvis","nauvis, gleba","nauvis, gleba, aquilo", "nauvis, gleba, vulcanus", "nauvis, gleba, aquilo, vulcanus","all planets", "no restrictions"},
		order = "b-b"
	},
})
end