local Recipe = require('__kry_stdlib__/stdlib/data/recipe')
local Technology = require('__kry_stdlib__/stdlib/data/technology')

--List of recipes that need to be manually added to the list
--  These technically could/should be added by the original mod author
--  but it's faster and eaaier to add them myself.
require("prototypes/added_manual_recipes")
--[[
local longlist = {}
for _, recipe in pairs (data.raw.recipe) do
	if recipe.category then
		if string.match(recipe.category,"recycling") then
			if recipe.results[1].extra_count_fraction then
				table.insert(longlist, recipe)
			end
		end
	end
end
rf.debug(longlist)
]]--
if mods["IndustrialRevolution"] then
	--Hide and disable the scrapper recipe
	Recipe("iron-scrapper"):remove_unlock("automation-2")
	Recipe("iron-scrapper"):set_enabled(false)
	data.raw.recipe["iron-scrapper"].hidden = true

	local scraplist = {"iron","copper","tin","gold","bronze","steel","lead","glass","titanium","duranium","stainless"}
	if data.raw.item["tantalum-ingot"] and data.raw.item["tantalum-scrap"] then table.insert(scraplist,"tantalum") end
	for _, material in pairs(scraplist) do
		name = material.."-ingot-from-scrap"
		Recipe(name):set_enabled(false)
		Recipe(name):set_field("hidden", true)
		--data.raw.recipe[name].hidden = true
		for _, tech in pairs(data.raw.technology) do
			if tech.effects then
				for _, unlock in pairs(tech.effects) do
					if unlock.type == "unlock-recipe" then
						if unlock.recipe == name then
							Recipe(unlock.recipe):remove_unlock(tech)
							Technology(tech):remove_effect(tech, "unlock-recipe",unlock.recipe)
						end
					end
				end
			end
		end
	end
end

--Cheap cliff explosives setting makes the reverse recipe crash
if mods["FTweaks"] then
	if Config.cheapCliffExplosives then
		for key1, ingredient in pairs(data.raw.recipe["cliff-explosives"].ingredients) do
			for key2, item in ipairs(ingredient) do
				if string.match(item, "item") then
					data.raw.recipe["cliff-explosives"].ingredients[key1][key2] = nil
					data.raw.recipe["cliff-explosives"].ingredients[key1]["item"] = "item"
				end
			end
		end
	end
end

--This function can be prevented from running by using "rf.prevent_final_fixes()" in data.lua
--DO NOT USE THIS FUNCTION IN YOUR MOD- DOWNLOAD reverse-factory-postprocess INSTEAD
function rf.final_fixes()

--List of item types to be recycled
local itemTypes = { --removed fluids from the list for now
	"ammo","armor","item","rail-planner","gun","capsule","module","tool","repair-tool","item-with-entity-data"--,"fluid"
}

--Overrides default gray fluid icons with custom ones (only for vanilla/space age)
local customFluidIcons = {"crude-oil","heavy-oil","light-oil","petroleum-gas","lubricant","sulfuric-acid"}
--Override default crafting machine tint with ones copied from vanilla/space age
local customFluidTints = {"crude-oil","heavy-oil","light-oil","petroleum-gas","lubricant","sulfuric-acid"}
--Override default recipe conditions with ones copied from space age (none in vanilla so far)
local customFluidRecipe = {}

--Add space age exclusive fluids to the override lists
if mods["space-age"] then
	--Custom Icons
	table.insert(customFluidIcons,"electrolyte")
	table.insert(customFluidIcons,"holmium-solution")
	table.insert(customFluidIcons,"ammoniacal-solution")
	table.insert(customFluidIcons,"ammonia")
	table.insert(customFluidIcons,"lithium-brine")
	table.insert(customFluidIcons,"fluoroketone-cold")
	--Custom Tints
	--table.insert(customFluidTints,"thruster-fuel")
	--table.insert(customFluidTints,"thruster-oxidizer")
	--table.insert(customFluidRecipe,"thruster-fuel")
	--table.insert(customFluidRecipe,"thruster-oxidizer")
else
	table.insert(customFluidIcons,"water")
end

--Makes item versions of every non-blacklisted fluid in the game
if rf.solidfluids then
	-- we need this table for later, trust me
	rf.addedfluids = {}
	for _, fluid in pairs(data.raw.fluid) do
		local blacklisted = false
		for _, name in pairs(rf.nofluid_items) do
			if fluid.name==name then
				blacklisted = true
			end
		end
		if not blacklisted then
			if not fluid.hidden then
				makeFluidItem(fluid)
			end
		end
	end
	--Update the fluids
	for _, fluid in pairs(customFluidIcons) do
		overrideFluidIcons(fluid)
	end
	for _, fluid in pairs(customFluidTints) do
		overrideFluidTint(fluid)
	end
	for _, fluid in pairs(customFluidRecipe) do
		overrideFluidRecipe(fluid)
	end
end

--Automatic reverse recipe creation
for _, itemType in pairs(itemTypes) do
	addRecipes(itemType, data.raw[itemType])
end

--Manual recipes added
for _, recycle in pairs(rf.custom_recycle) do
	local itemType = recycle[1]
	local item = data.raw[itemType][recycle[2]]
	local recipe = data.raw.recipe[recycle[3]]
	makeRecipe(itemType, item, recipe)
	log("manual recipe added: "..item.name)
end

--Convert fluid results to items if that setting is enabled
--[[
for _, recipe in pairs(rf.fluidrecipe_list) do
	convertFluidResults(data.raw.recipe[recipe])
end]]--

--Fix required for Factorio 2.0, to allow early recycling of barrels.
data.raw.recipe["rf-barrel"].category = "recycle-products"

for n=1,3 do
	data.raw["furnace"]["reverse-factory-"..n].result_inventory_size = rf.maxResults[n]
	if mods["nullius"] then
		data.raw["furnace"]["nullius-reverse-factory-"..n].result_inventory_size = rf.maxResults[n]
	end
	-- also apply the changes to mini reverse factory
	if mods["mini-machines"] then
		if settings.startup["mini-rf"].value then
		data.raw["furnace"]["mini-reverse-factory-"..n].result_inventory_size = rf.maxResults[n]
		end
	end
	-- also apply the changes to micro reverse factory
	if mods["micro-machines"] then
		if settings.startup["micro-rf"].value then
		data.raw["furnace"]["micro-reverse-factory-"..n].result_inventory_size = rf.maxResults[n]
		end
	end
end
end

if not rf.prevented_final_fixes then
	rf.final_fixes()
end

