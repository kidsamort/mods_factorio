data:extend({
--Categories for reverse recipes, used to define tiers
	{
		type = "recipe-category",
		name = "recycle-products"
	},
	{
		type = "recipe-category",
		name = "recycle-intermediates"
	},
	{
		type = "recipe-category",
		name = "recycle-productivity"
	},
--Hidden group and subgroup which contains the reverse recipes
	{
		type = "item-group",
		name = "recycling",
		icon = "__reverse-factory__/graphics/technology/reverse-factory.png",
		icon_size = 128,
		order = "z",
	},
	{
		type = "item-subgroup",
		name = "recycling",
		group = "recycling",
		order = "z",
	},
--New set of subgroups for solid fluid items
	{
		type = "item-subgroup",
		name = "fluid-items",
		group = "intermediate-products",
		order = "a-b",
	},
	{
		type = "item-subgroup",
		name = "fluid-conversion",
		group = "intermediate-products",
		order = "a-c",
	}
})