if storage.ocfg.gameplay.scale_spawner_damage == nil then
    storage.ocfg.gameplay.scale_spawner_damage = false
    log("Updating gameplay config with new 'scale_spawner_damage' setting.")
end