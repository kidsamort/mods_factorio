This is provided only for advanced server hosts who want to run headless configurations and configure all the available settings in the config.lua file!
You must copy the OARC folder (rename if you want) to your own scenarios folder.
Then edit the control.lua file. Follow the instructions in the control.lua file!