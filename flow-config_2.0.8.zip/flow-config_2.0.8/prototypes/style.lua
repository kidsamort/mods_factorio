data.raw["gui-style"]["default"].fc_toggle_button =
{
  type = "button_style",
  parent = "button",
  icon_horizontal_align = "left",
  horizontal_align = "right",
  left_padding = 0,
  right_padding = 4,
  disabled_font_color = {120, 120, 120},
}
