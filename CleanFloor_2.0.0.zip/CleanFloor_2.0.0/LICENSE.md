Skrunix Software License
========================

Permission to use, copy, modify, and/or distribute this software is
outlined in the latest v0.0.x of https://github.com/Skrunix/license

THE SOFTWARE IS PROVIDED "AS IS"
