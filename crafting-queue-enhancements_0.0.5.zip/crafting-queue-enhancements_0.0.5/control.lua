local e = defines.events

script.on_init(function()
    storage.front = {} --[[@as table<uint, boolean>]]
    storage.temp_front = {} --[[@as table<uint, boolean>]]
    storage.requeueing = {} --[[@as table<uint, boolean>]]
    storage.crafting_bonus = {} --[[@as table<uint, double>]]
end)

---@param player LuaPlayer
local function player_cannot_craft(player)
    return not (player.controller_type == defines.controllers.character or player.controller_type == defines.controllers.god)
end

script.on_event("cqe-pause", function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    if not storage.crafting_bonus[event.player_index] then
        storage.crafting_bonus[event.player_index] = player.character_crafting_speed_modifier
        player.character_crafting_speed_modifier = -1
        player.create_local_flying_text{
            create_at_cursor = true,
            text = {"crafting-queue-enhancements.pause"}
        }
    else
        player.character_crafting_speed_modifier = storage.crafting_bonus[event.player_index]
        storage.crafting_bonus[event.player_index] = nil
        player.create_local_flying_text{
            create_at_cursor = true,
            text = {"crafting-queue-enhancements.unpause"}
        }
    end
end)

script.on_event("cqe-toggle", function(event)
    local index = event.player_index
    local front = not storage.front[index]
    storage.front[index] = front

    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    local front_or_back = front and {"crafting-queue-enhancements.front"} or {"crafting-queue-enhancements.back"}
    player.create_local_flying_text{
        create_at_cursor = true,
        text = {"crafting-queue-enhancements.toggle-message", front_or_back},
    }
end)

local counts = {["cqe-craft"] = 1, ["cqe-craft-5"] = 5}
---@param event EventData.CustomInputEvent
script.on_event({"cqe-craft", "cqe-craft-5", "cqe-craft-all"}, function(event)
    local prototype = event.selected_prototype
    if not prototype then return end
    if prototype.base_type ~= "recipe" then return end

    storage.temp_front[event.player_index] = true
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    player.begin_crafting{
        recipe = prototype.name,
        count = counts[event.input_name] or player.get_craftable_count(prototype.name),
        silent = false,
    }
end)

---@param player LuaPlayer
local function get_useful_queue(player)
    local useful_queue = {}
    local c = 0
    for _, queue_item in pairs(player.crafting_queue) do
        if not queue_item.prerequisite then
            c = c + 1
            useful_queue[c] = {recipe = queue_item.recipe, count = queue_item.count}
        end
    end
    return useful_queue, c
end

---@param player LuaPlayer
local function cancel_all(player)
    while player.crafting_queue_size > 0 do
        player.cancel_crafting{index = 1, count = player.crafting_queue[1].count}
    end
end

---@param player LuaPlayer
---@param amount number
---@param keep_inventory boolean?
local function requeue(player, amount, keep_inventory)
    if player_cannot_craft(player) then return end
    if not player.crafting_queue then return end

    local useful_queue, queue_size = get_useful_queue(player)
    if queue_size <= 1 then return end

    local inventory, inventory_size, temp_inventory
    if not keep_inventory then
        inventory = player.get_main_inventory() --[[@as LuaInventory]]
        inventory_size = #inventory
        temp_inventory = game.create_inventory(inventory_size)
        for i = 1, inventory_size do
            if not temp_inventory[i].transfer_stack(inventory[i]) then game.print("uh oh") end
        end
    end

    local first_recipe = player.crafting_queue[1].recipe
    local progress = player.crafting_queue_progress

    local old_bonus = player.character_inventory_slots_bonus
    player.character_inventory_slots_bonus = player.character_inventory_slots_bonus + 1000

    cancel_all(player)

    amount = amount or 0

    storage.requeueing[player.index] = true
    for i = amount, amount + queue_size - 1 do
        player.begin_crafting(useful_queue[(i + queue_size) % queue_size + 1])
    end
    storage.requeueing[player.index] = nil

    player.character_inventory_slots_bonus = old_bonus

    if player.crafting_queue[1].recipe == first_recipe then
        player.crafting_queue_progress = math.min(progress, 1)
    end

    if not keep_inventory then
        for i = 1, inventory_size do
            inventory[i].transfer_stack(temp_inventory[i])
        end
        temp_inventory.destroy()
    end
end

script.on_event(e.on_pre_player_crafted_item, function(event)
    if storage.requeueing[event.player_index] then return end
    if storage.temp_front[event.player_index] then
        storage.temp_front[event.player_index] = nil
    elseif not storage.front[event.player_index] then
        return
    end

    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    requeue(player, -1)
end)

script.on_event("cqe-requeue", function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    requeue(player, 0, true)
end)

script.on_event("cqe-move-to-front", function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    requeue(player, -1)
end)

script.on_event("cqe-move-to-back", function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    requeue(player, 1)
end)

script.on_event("cqe-cancel-all", function(event)
    local player = game.get_player(event.player_index) --[[@as LuaPlayer]]
    if player_cannot_craft(player) then return end

    cancel_all(player)
end)