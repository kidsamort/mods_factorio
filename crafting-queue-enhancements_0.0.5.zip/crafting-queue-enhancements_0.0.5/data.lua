data:extend{{
    type = "custom-input",
    name = "cqe-toggle",
    key_sequence = "ALT + Q",
}, {
    type = "custom-input",
    name = "cqe-pause",
    key_sequence = "SHIFT + ALT + Q",
}, {
    type = "custom-input",
    name = "cqe-requeue",
    key_sequence = "CONTROL + SHIFT + Q",
}, {
    type = "custom-input",
    name = "cqe-craft",
    key_sequence = "CONTROL + ALT + mouse-button-1",
    include_selected_prototype = true,
}, {
    type = "custom-input",
    name = "cqe-craft-5",
    key_sequence = "CONTROL + ALT + mouse-button-2",
    include_selected_prototype = true,
}, {
    type = "custom-input",
    name = "cqe-craft-all",
    key_sequence = "CONTROL + SHIFT + ALT + mouse-button-1",
    alternative_key_sequence = "CONTROL + SHIFT + ALT + mouse-button-2",
    include_selected_prototype = true,
}, {
    type = "custom-input",
    name = "cqe-move-to-front",
    key_sequence = "CONTROL + ALT + RIGHT",
    include_selected_prototype = true,
}, {
    type = "custom-input",
    name = "cqe-move-to-back",
    key_sequence = "CONTROL + ALT + LEFT",
    include_selected_prototype = true,
}, {
    type = "custom-input",
    name = "cqe-cancel-all",
    key_sequence = "CONTROL + SHIFT + ALT + C",
    include_selected_prototype = true,
}}