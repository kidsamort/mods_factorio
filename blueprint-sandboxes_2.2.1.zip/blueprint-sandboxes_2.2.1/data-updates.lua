BPSB = require("scripts.bpsb")
Settings = require("scripts.settings")

require("prototypes.recipes.hidden-vanilla-updates")
require("prototypes.tiles-updates")
