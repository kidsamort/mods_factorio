BPSB = require("scripts.bpsb")

require("prototypes.recipes.hidden-vanilla-final-fixes")
require("prototypes.illusions-final-fixes")
