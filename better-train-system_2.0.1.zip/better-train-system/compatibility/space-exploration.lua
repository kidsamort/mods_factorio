if not mods['space-exploration'] then return end

-- change subgroups
data.raw["item-with-entity-data"]['locomotive-mk2'].subgroup = 'rail'
data.raw["item-with-entity-data"]['locomotive-mk3'].subgroup = 'rail'
data.raw["item-with-entity-data"]['locomotive-mk4'].subgroup = 'rail'

data.raw["item-with-entity-data"]['cargo-wagon-mk2'].subgroup = 'rail'
data.raw["item-with-entity-data"]['cargo-wagon-mk3'].subgroup = 'rail'
data.raw["item-with-entity-data"]['cargo-wagon-mk4'].subgroup = 'rail'

data.raw["item-with-entity-data"]['fluid-wagon-mk2'].subgroup = 'rail'
data.raw["item-with-entity-data"]['fluid-wagon-mk3'].subgroup = 'rail'
data.raw["item-with-entity-data"]['fluid-wagon-mk4'].subgroup = 'rail'
