This mod is a fork from https://github.com/TheTorukMakto/factorio-assembler-craft-rates.

I only fork to make it compatible with space age.

All credit go to the original creator of the mod TheTorukMakto