The expansion brought a hidden entity called the lane splitter, which is effectively a splitter for just one belt.

Hidden inside the game itself there is only an entity for the yellow splitter, with just a scaled down splitter texture.

This mod adds the entity for the red and blue tiers, as well as for green if you have space age enabled.
(the lane splitter itself is not locked behind an expansion feature flag, so from the 21st anyone can use it)

The recipes are the same as for the splitters but the recipe just crafts two, they're under the same technology too.

- third party belt support: submit a pull request with the **splitter texture** that is a recolor of the vanilla style splitter, and modify the data with your tier.
