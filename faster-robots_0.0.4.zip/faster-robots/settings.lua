data:extend({{
    type = "double-setting",
    name = "faster-robots-speed",
    localised_name = "Robot speed",
    localised_description = "Base game speed is 0.05",
    setting_type = "startup",
    minimum_value = 0.05,
    default_value = 1
}})
