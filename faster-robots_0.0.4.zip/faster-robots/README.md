# Factorio Faster Robots
Improves base speed of both, logistic and construction, robots

# Mod Page
https://mods.factorio.com/mod/faster-robots
