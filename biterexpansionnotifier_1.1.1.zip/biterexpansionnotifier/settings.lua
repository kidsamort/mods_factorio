data:extend(
{
  {
    type = "bool-setting",
    name = "benn-biter-chat-alert",
    setting_type = "runtime-per-user",
    default_value = false,
  },
  {
    type = "bool-setting",
    name = "benn-biter-map-alert",
    setting_type = "runtime-per-user",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "benn-include-uncharted",
    setting_type = "runtime-per-user",
    default_value = false
  },
  {
    type = "bool-setting",
    name = "benn-chart-expansions",
    setting_type = "runtime-global",
    default_value = false
  }
}
)
