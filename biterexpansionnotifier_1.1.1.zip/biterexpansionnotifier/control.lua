storage.benn = {x = 0, y = 0}

local function distance(pos1, pos2)
  return ((pos1.x - pos2.x) ^ 2 + (pos1.y - pos2.y) ^ 2) ^ 0.5
end

local function distance_sort(tbl, origin)
  table.sort(tbl, function(e1, e2)
    return distance(origin, e1.position) < distance(origin, e2.position)
  end)
  return tbl
end

local function is_revealed(force, surface, position)
  position = {x = position.x / 32, y = position.y / 32}
  if force.is_chunk_charted(surface, position) then
    return true
  end
  if force.is_chunk_requested_for_charting(surface, position) then
    return true
  end
  return false
end

local function re_init(event)
  -- Build global state if it doesn't exist (i.e. mod update)
  storage.benn = storage.benn or {x = 0, y = 0}
end

script.on_init(re_init)
script.on_configuration_changed(re_init)

script.on_event(defines.events.on_biter_base_built, function(event)
  local entity = event.entity
  if not entity.valid then
    return
  end

  local target_position = storage.benn
  local should_notify = distance({x = 0, y = 0}, target_position) > 0
  -- Indicate that we've notified for this colony
  storage.benn = {x = 0, y = 0}

  local chart_expansions = settings.global["benn-chart-expansions"].value
  local position = entity.position
  local surface = entity.surface
  local planet = surface.planet

  -- First entity, sorted by distance (since radius search doesn't seem to do that)
  local target = should_notify and distance_sort(surface.find_entities_filtered({
    position = target_position,
    name = entity.name,
    radius = 30
  }), target_position)[1]

  -- This means we likely have overlapping colonies and don't need a new notification
  if target and target ~= entity then
    log(string.format(
      "nearest %s to %s isn't %s (got %s), skipping notification",
      entity.name,
      serpent.line(target_position),
      entity,
      target or "nil"
    ))
    return
  end

  for _, force in pairs(game.forces) do
    -- If the planet is locked, we skip the force entirely
    if planet and not force.is_space_location_unlocked(planet.name) then
      goto NEXT_FORCE
    end
    -- If the position is charted, we refresh it to show the red dots on the map
    local position_revealed = is_revealed(force, surface, position)
    if position_revealed and chart_expansions then
      force.chart(surface, entity.selection_box)
    end
    -- If we've already notified for this colony, we can skip the player-logic
    if not should_notify then
      goto NEXT_FORCE
    end
    -- and now we deal with the player logic
    for _, player in pairs(force.connected_players) do
      local player_settings = settings.get_player_settings(player)
      -- Skip if uncharted and setting is off
      if not position_revealed and not player_settings["benn-include-uncharted"].value then
        --[[log(string.format(
          "Skipping notification for player %s, {%s, %s} is not revealed",
          player.name,
          position.x,
          position.y
        ))]]
        goto NEXT_PLAYER
      end
      if player_settings["benn-biter-chat-alert"].value then
        player.print({"alert-description.biter-base-built-desc", math.floor(position.x+0.5), math.floor(position.y+0.5), surface.name})
      end
      if player_settings["benn-biter-map-alert"].value then
        player.add_custom_alert(
          entity,
          {
            type = "virtual",
            name = "biter-warning"
          },
          {"alert-description.biter-base-built", math.floor(position.x+0.5), math.floor(position.y+0.5), surface.name},
          true
        )
      end
      ::NEXT_PLAYER::
    end
    ::NEXT_FORCE::
  end
end)

script.on_event(defines.events.on_build_base_arrived, function(event)
  local party = event.group
  -- no LuaCommandable
  if not party or not party.valid then
    return
  end
  -- No command
  if not party.command or party.command.type ~= defines.command.build_base then
    return
  end
  -- Store the destination
  storage.benn = party.command.destination
end)