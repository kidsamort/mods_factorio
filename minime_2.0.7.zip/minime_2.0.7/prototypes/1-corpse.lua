minime.entered_file()

------------------------------------------------------------------------------------
-- Define generic character corpse.
-- If a player used a character from a mod that was removed later on, both the
-- character and its corpse will be removed from the game. Thus, players will lose
-- all items they were carrying when they died. We should place a generic corpse in
-- that case, so we can restore removed corpses.
local corpse = table.deepcopy(data.raw["character-corpse"]["character-corpse"])
corpse.name = minime.modName.."_generic_corpse"

data:extend({corpse})
minime.created_msg(corpse)


------------------------------------------------------------------------------------
minime.entered_file("leave")
