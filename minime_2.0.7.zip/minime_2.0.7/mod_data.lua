-- Settings for calling Pi-C_lib
return {
  mod_name = "minime",
  mod_shortname = "minime",
  debug_log_setting = "minime_debug_to_log",
  debug_log_setting_type = "startup",
  debug_game_setting = nil,
  debug_game_setting_type = nil,
}
