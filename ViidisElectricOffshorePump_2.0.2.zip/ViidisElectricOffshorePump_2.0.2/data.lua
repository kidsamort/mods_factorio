local function copyIcon(from, to)
    to.icons = from.icons
    to.icon = from.icon
    to.icon_size = from.icon_size
    to.icon_mipmaps = from.icon_mipmaps
end

local entity = table.deepcopy(data.raw["offshore-pump"]["offshore-pump"])

entity.name = "electric-offshore-pump"
entity.minable.result = entity.name
entity.tile_buildability_rules = nil
entity.collision_mask = nil
entity.fluid_box.filter = "water"
entity.energy_source = {
    type = "electric",
    usage_priority = "secondary-input"
}
entity.energy_usage = "20kW"

entity.icon = data.raw["offshore-pump"]["offshore-pump"].icon
entity.icon_size = data.raw["offshore-pump"]["offshore-pump"].icon_size
entity.icon_mipmaps = data.raw["offshore-pump"]["offshore-pump"].icon_mipmaps
entity.icons = {
    {
        icon = data.raw["offshore-pump"]["offshore-pump"].icon,
        icon_size = data.raw["offshore-pump"]["offshore-pump"].icon_size,
        icon_mipmaps = data.raw["offshore-pump"]["offshore-pump"].icon_mipmaps,
    },
    {
        icon = data.raw["item"]["copper-cable"].icon,
        icon_size = data.raw["item"]["copper-cable"].icon_size,
        icon_mipmaps = data.raw["item"]["copper-cable"].icon_mipmaps,
        scale = .5,
        shift = { -5, 9 }
    },
    {
        icon = data.raw["fluid"]["water"].icon,
        icon_size = data.raw["fluid"]["water"].icon_size,
        icon_mipmaps = data.raw["fluid"]["water"].icon_mipmaps,
        scale = .3,
        shift = { 5, 9 }
    },
}

local item = table.deepcopy(data.raw["item"]["offshore-pump"])
item.name = entity.name
item.place_result = entity.name

copyIcon(entity, item)

local recipe = table.deepcopy(data.raw["recipe"]["offshore-pump"])
recipe.ingredients[#recipe.ingredients + 1] = { type = "item", name = "copper-cable", amount = 6 }
copyIcon(entity, recipe)
recipe.name = entity.name
recipe.results = {
    { type = "item", name = item.name, amount = 1 }
}

local tech = data.raw["technology"]["steam-power"]
tech.effects[#tech.effects + 1] = {
    type = "unlock-recipe",
    recipe = recipe.name
}

data:extend { entity, item, recipe }