script.on_init(
    function()
        for _, force in pairs(game.forces) do
            if force.technologies["steam-power"].researched then
                force.recipes["electric-offshore-pump"].enabled = true
            end
        end
    end
)
