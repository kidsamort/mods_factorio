data:extend({
		{
        type = "sprite",
        name = "ivl_down",
        filename = "__InserterVisualizerLite__/graphics/down.png",
        priority = "extra-high-no-scale",
        size = 30,
        flags = {"icon"},
    },
		{
        type = "sprite",
        name = "ivl_up",
        filename = "__InserterVisualizerLite__/graphics/up.png",
        priority = "extra-high-no-scale",
        size = 30,
        flags = {"icon"},
    },
		{
        type = "sprite",
        name = "ivl_cross",
        filename = "__InserterVisualizerLite__/graphics/cross.png",
        priority = "extra-high-no-scale",
        size = 34,
        flags = {"icon"},
    }
})
