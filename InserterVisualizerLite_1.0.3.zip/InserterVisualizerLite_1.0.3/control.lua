-- Magic explained here: https://wiki.factorio.com/Inserters#Inserters_and_transport_belts

-- Directions 0=north;1=northnortheast;2=... (not to confuse with orientation which is a float [0, 1))

local _OFFSET_ICON = 0.2

local _TYPES_ALLOWED = {"transport-belt", "underground-belt", "splitter"}
local _TYPES_ALLOWED_BY_KEY = {}
for _, type in ipairs(_TYPES_ALLOWED) do
	_TYPES_ALLOWED_BY_KEY[type] = true
end

local _player_index = nil

-- This will calculate the relative direction between two directions
-- Order is important, see examples: 
-- (south (4) - east  (2)) % 8 = 2 -> left
-- (east  (2) - south (4)) % 8 = 6 -> right
-- (north (0) - west  (6)) % 8 = 2 -> left
local function calc_relative_dir(dir_start, dir_end)
	--return (dir_start - dir_end) % 8 -- magic number 8 = amount of directions
	return ((dir_start - dir_end) % 16) / 2 -- magic number 16 = amount of directions | 2.0
end

local function calc_drop_position(inserter)
	local pos = inserter.drop_position
	
	local drop_target = inserter.drop_target
	if not drop_target then
		drop_target = inserter.surface.find_entities_filtered({
			type = _TYPES_ALLOWED,
			position = pos,
			limit = 1
		})[1]
	end
	
	if not drop_target or not drop_target.type or not _TYPES_ALLOWED_BY_KEY[drop_target.type] then
		return
	end
	
	local function adjust_axis(x_mul, y_mul)
		local x = _OFFSET_ICON * x_mul
		local y = _OFFSET_ICON * y_mul
	
		local dc = 0
		local inputs = drop_target.belt_neighbours.inputs
		-- only belts can have curves
		if drop_target.type == "transport-belt" and #inputs == 1 and drop_target.direction ~= inputs[1].direction then
		  -- TODO maybe use drop_target.belt_shape here?!
			dc = calc_relative_dir(drop_target.direction, inputs[1].direction)
		end
		
		local di = calc_relative_dir(inserter.direction, drop_target.direction)
		--l("DROP curve: " .. dc .. " | inserter: " .. di .. " | " .. x_mul .. "," .. y_mul .. " | dir: " .. inserter.direction)
		
		--local is_horizontal = inserter.direction == 2 or inserter.direction == 6
		local is_horizontal = inserter.direction == 4 or inserter.direction == 12 -- 2.0
		
		if (dc == 0 and di == 2) or (dc == 0 and di == 6) then	
			-- do not use default!
		elseif (dc == 0 and di == 0) or (dc == 2 and di == 0) or (dc == 6 and di == 4) then
			if is_horizontal then
				pos.y = pos.y + y
			else
				pos.x = pos.x + x
			end
		elseif dc == 0 and di == 4 then
			if is_horizontal then
				pos.y = pos.y - y
			else
				pos.x = pos.x - x
			end
		elseif dc == 2 and di == 6 then
			if is_horizontal then
				pos.y = pos.y + y
			else
				pos.x = pos.x + x
			end
		elseif (dc == 6 and di == 2) or (dc == 2 and di == 4) or (dc == 6 and di == 0) then
			if is_horizontal then
				pos.y = pos.y - y
			else
				pos.x = pos.x - x
			end
		else
			--l("d default")
			pos.x = pos.x + x
			pos.y = pos.y + y
		end
	end

	local direction = inserter.direction
	if direction == defines.direction.north then
		adjust_axis(1, 1)
	elseif direction == defines.direction.east then
		adjust_axis(-1, 1)
	elseif direction == defines.direction.south then
		adjust_axis(-1, -1)
	elseif direction == defines.direction.west then
		adjust_axis(1, -1)
	end
	
	local pos_icon = {
		x = pos.x - inserter.position.x,
		y = pos.y - inserter.position.y,
	}
	
	local pos_cross = {
		x = drop_target.position.x - inserter.position.x,
		y = drop_target.position.y - inserter.position.y,
	}
	
	return pos_icon, pos_cross
end

local function calc_pickup_position(inserter)
	local pos = inserter.pickup_position
	
	local pickup_target = inserter.pickup_target
	if not pickup_target then
		pickup_target = inserter.surface.find_entities_filtered({
			type = _TYPES_ALLOWED,
			position = pos,
			limit = 1
		})[1]
	end
	
	if not pickup_target or not pickup_target.type or not _TYPES_ALLOWED_BY_KEY[pickup_target.type] then
		return
	end

	local function adjust_axis(x_mul, y_mul)
		local x = _OFFSET_ICON * x_mul
		local y = _OFFSET_ICON * y_mul
	
		local dc = 0
		local inputs = pickup_target.belt_neighbours.inputs
		-- only belts can have curves
		if pickup_target.type == "transport-belt" and #inputs == 1 and pickup_target.direction ~= inputs[1].direction then
			dc = calc_relative_dir(pickup_target.direction, inputs[1].direction)
		end
		
		local di = calc_relative_dir(inserter.direction, pickup_target.direction)
		--l("PICKUP curve: " .. dc .. " | inserter: " .. di .. " | " .. x_mul .. "," .. y_mul .. " | dir: " .. inserter.direction)
		
		-- local is_horizontal = inserter.direction == 2 or inserter.direction == 6
		local is_horizontal = inserter.direction == 4 or inserter.direction == 12 -- 2.0
		
		if (dc == 0 and di == 6) or (dc == 0 and di == 0) then
			if is_horizontal then
				pos.x = pos.x + x
				pos.y = pos.y - y
			else
				pos.x = pos.x - x
				pos.y = pos.y + y
			end
		elseif (dc == 0 and di == 4) or (dc == 2 and di == 2) or (dc == 6 and di == 6) then
			if is_horizontal then
				pos.x = pos.x - x
				pos.y = pos.y + y
			else
				pos.x = pos.x + x
				pos.y = pos.y - y
			end
		elseif (dc == 2 and di == 4) or (dc == 6 and di == 0) then
			pos.x = pos.x - x
			pos.y = pos.y - y
		else
			--l("p default")
			pos.x = pos.x + x
			pos.y = pos.y + y
		end
	end
	
	local direction = inserter.direction
	if direction == defines.direction.north then
		adjust_axis(1, 1)
	elseif direction == defines.direction.east then
		adjust_axis(-1, 1)
	elseif direction == defines.direction.south then
		adjust_axis(-1, -1)
	elseif direction == defines.direction.west then
		adjust_axis(1, -1)
	end
	
	local pos_icon = {
		x = pos.x - inserter.position.x,
		y = pos.y - inserter.position.y,
	}
	
	local pos_cross = {
		x = pickup_target.position.x - inserter.position.x,
		y = pickup_target.position.y - inserter.position.y,
	}
	
	return pos_icon, pos_cross
end

local on_event = function(event)
	_player_index = event.player_index
	local player = game.get_player(_player_index)
	if not player then 
		return 
	end
	
	if not storage.players then
		storage.players = {}
	end
	
	if not storage.players[_player_index] then
		storage.players[_player_index] = {render_ids={}}
	end

	-- destroy previous renderings on any registered event
	local t = storage.players[_player_index].render_ids
	for _, render_id in ipairs(t) do
		--rendering.destroy(render_id)
		render_id.destroy()
	end
	t = {}
	storage.players[_player_index].render_ids = t
	
	local entity = player.selected
	if not entity or not entity.valid then
		return
	end
	
	if entity.type ~= "inserter" then
		return
	end
	
	local pos_icon, pos_cross = calc_drop_position(entity)
	if pos_icon then
		draw("ivl_cross", pos_cross, entity) -- cross is bottom layer!
		draw("ivl_down", pos_icon, entity)
	end
	
	local pos_icon, pos_cross = calc_pickup_position(entity)
	if pos_icon then
		draw("ivl_cross", pos_cross, entity) -- cross is bottom layer!
		draw("ivl_up", pos_icon, entity)
	end
end

function draw(sprite, pos, entity)
	local pos_off = {x = entity.position.x + pos.x, y = entity.position.y + pos.y}

	local render_id = rendering.draw_sprite({
		sprite  = sprite,
		target = pos_off, -- 2.0
		--target = entity,
		--target_offset = pos,
		surface = entity.surface,
		players = {_player_index},
		x_scale = 0.5,
		y_scale = 0.5,
	})
			
	local t = storage.players[_player_index].render_ids
	table.insert(t, render_id)
end

script.on_event(defines.events.on_selected_entity_changed, on_event)
script.on_event(defines.events.on_player_rotated_entity, on_event)

--function l(text)
--	game.print(text, {skip = defines.print_skip.never})
--end
