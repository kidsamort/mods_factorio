data.raw["electric-pole"]["big-electric-pole"].collision_mask = {layers={object=true, is_object=true, is_lower_object=true}}
