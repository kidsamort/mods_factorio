local IMG_PATH = HUTAO.IMG_PATH

local hutao_anims = {
	idle = {
		width = 160,
		height = 160,
		frame_count = 22,
		animation_speed = 0.167,
		axially_symmetrical = false,
		direction_count = 8,
		stripes = {
			{
				filename = IMG_PATH.."idle.png",
				width_in_frames = 22,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 22,
			animation_speed = 0.167,
			axially_symmetrical = false,
			direction_count = 8,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-idle.png",
					width_in_frames = 22,
					height_in_frames = 8
				}
			}
		}
	},
	idle_shadow = {
		width = 160,
		height = 160,
		frame_count = 22,
		animation_speed = 0.167,
		axially_symmetrical = false,
		direction_count = 8,
		draw_as_shadow = true,
		stripes = {
			{
				filename = IMG_PATH.."idle-shadow.png",
				width_in_frames = 22,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 22,
			animation_speed = 0.167,
			axially_symmetrical = false,
			direction_count = 8,
			draw_as_shadow = true,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-idle-shadow.png",
					width_in_frames = 22,
					height_in_frames = 8
				}
			}
		}
	},
	mining = {
		width = 160,
		height = 160,
		frame_count = 2,
		animation_speed = 0.067,
		axially_symmetrical = false,
		direction_count = 8,
		stripes = {
			{
				filename = IMG_PATH.."idle.png",
				width_in_frames = 2,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 2,
			animation_speed = 0.067,
			axially_symmetrical = false,
			direction_count = 8,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-idle.png",
					width_in_frames = 2,
					height_in_frames = 8
				}
			}
		}
	},
	mining_shadow = {
		width = 160,
		height = 160,
		frame_count = 2,
		animation_speed = 0.067,
		axially_symmetrical = false,
		direction_count = 8,
		draw_as_shadow = true,
		stripes = {
			{
				filename = IMG_PATH.."idle-shadow.png",
				width_in_frames = 2,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 2,
			animation_speed = 0.067,
			axially_symmetrical = false,
			direction_count = 8,
			draw_as_shadow = true,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-idle-shadow.png",
					width_in_frames = 2,
					height_in_frames = 8
				}
			}
		}
	},
	run = {
		width = 160,
		height = 160,
		direction_count = 8,
		frame_count = 22,
		animation_speed = 0.56,
		axially_symmetrical = false,
		stripes = {
			{
				filename = IMG_PATH.."running.png",
				width_in_frames = 11,
				height_in_frames = 16
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			direction_count = 8,
			frame_count = 22,
			animation_speed = 0.56,
			axially_symmetrical = false,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-running.png",
					width_in_frames = 11,
					height_in_frames = 16
				}
			}
		}
	},
	run_shadow = {
		width = 160,
		height = 160,
		direction_count = 8,
		frame_count = 22,
		animation_speed = 0.56,
		axially_symmetrical = false,
		draw_as_shadow = true,
		stripes = {
			{
				filename = IMG_PATH.."running-shadow.png",
				width_in_frames = 11,
				height_in_frames = 16
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			direction_count = 8,
			frame_count = 22,
			animation_speed = 0.56,
			axially_symmetrical = false,
			draw_as_shadow = true,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-running-shadow.png",
					width_in_frames = 11,
					height_in_frames = 16
				}
			}
		}
	},
	gun_idle = {
		width = 160,
		height = 160,
		frame_count = 22,
		animation_speed = 0.167,
		axially_symmetrical = false,
		direction_count = 8,
		stripes = {
			{
				filename = IMG_PATH.."gun-idle.png",
				width_in_frames = 22,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 22,
			animation_speed = 0.167,
			axially_symmetrical = false,
			direction_count = 8,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-gun-idle.png",
					width_in_frames = 22,
					height_in_frames = 8
				}
			}
		}
	},
	gun_idle_shadow = {
		width = 160,
		height = 160,
		frame_count = 22,
		animation_speed = 0.167,
		axially_symmetrical = false,
		direction_count = 8,
		draw_as_shadow = true,
		stripes = {
			{
				filename = IMG_PATH.."gun-idle-shadow.png",
				width_in_frames = 22,
				height_in_frames = 8
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			frame_count = 22,
			animation_speed = 0.167,
			axially_symmetrical = false,
			direction_count = 8,
			draw_as_shadow = true,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-gun-idle-shadow.png",
					width_in_frames = 22,
					height_in_frames = 8
				}
			}
		}
	},
	gun_run = {
		width = 160,
		height = 160,
		direction_count = 18,
		frame_count = 22,
		animation_speed = 0.54,
		axially_symmetrical = false,
		stripes = {
			{
				filename = IMG_PATH.."gun-run.png",
				width_in_frames = 22,
				height_in_frames = 18
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			direction_count = 18,
			frame_count = 22,
			animation_speed = 0.54,
			axially_symmetrical = false,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-gun-run.png",
					width_in_frames = 22,
					height_in_frames = 18
				}
			}
		}
	},
	gun_run_shadow = {
		width = 160,
		height = 160,
		direction_count = 18,
		frame_count = 22,
		animation_speed = 0.54,
		axially_symmetrical = false,
		draw_as_shadow = true,
		stripes = {
			{
				filename = IMG_PATH.."gun-run-shadow.png",
				width_in_frames = 22,
				height_in_frames = 18
			}
		},
		hr_version = {
			width = 320,
			height = 320,
			direction_count = 18,
			frame_count = 22,
			animation_speed = 0.54,
			axially_symmetrical = false,
			draw_as_shadow = true,
			scale = 0.5,
			stripes = {
				{
					filename = IMG_PATH.."hr-gun-run-shadow.png",
					width_in_frames = 22,
					height_in_frames = 18
				}
			}
		}
	}
}


return {
	{
		idle = {
			layers = {
				hutao_anims.idle,
				hutao_anims.idle_shadow,
			}
		},
		idle_with_gun = {
			layers = {
				hutao_anims.gun_idle,
				hutao_anims.gun_idle_shadow,
			}
		},
		mining_with_tool = {
			layers = {
				hutao_anims.mining,
				hutao_anims.mining_shadow,
			}
		},
		running = {
			layers = {
				hutao_anims.run,
				hutao_anims.run_shadow,
			}
		},
		running_with_gun = {
			layers = {
				hutao_anims.gun_run,
				hutao_anims.gun_run_shadow,
			}
		},
		flipped_shadow_running_with_gun = {
			layers = {
				hutao_anims.gun_run_shadow,
			}
		}
	}
}