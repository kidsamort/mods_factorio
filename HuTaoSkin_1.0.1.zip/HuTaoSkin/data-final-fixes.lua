HUTAO.entered_file()
CharModHelper.check_my_prototypes(HUTAO.protos)
HUTAO.entered_file("leave")
