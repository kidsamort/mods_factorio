log("Entered file " .. debug.getinfo(1).source)

HUTAO = require("__CharacterModHelper__.common")("HuTaoSkin")

local LOGGING_DEFAULT = false
HUTAO.is_debug = mods["_debug"] and true or LOGGING_DEFAULT

HUTAO.IMG_PATH = HUTAO.modRoot.."/graphics/"
HUTAO.protos = {}
HUTAO.protos.character	= { name = require("name") }
HUTAO.protos.corpse		= { name = HUTAO.protos.character.name.."-corpse" }

HUTAO.protos.character.localised_name         = {"entity-name."..HUTAO.protos.character.name}
HUTAO.protos.character.localised_description  = {"entity-description."..HUTAO.protos.character.name}
HUTAO.protos.character.icons                  = {
  {
    icon = HUTAO.IMG_PATH.."hutao-icon.png",
    icon_size = 64,
  }
}
HUTAO.protos.character.animations             = require("animations")
HUTAO.protos.character.character_corpse       = HUTAO.protos.corpse.name
HUTAO.protos.character.fast_replaceable_group = "character"
HUTAO.protos.character.running_sound_animation_positions = {12, 1}

HUTAO.protos.corpse.name                      = HUTAO.protos.character.name.."-corpse"
HUTAO.protos.corpse.localised_name            = {"entity-name."..HUTAO.protos.corpse.name}
HUTAO.protos.corpse.icons                     = {
	{
		icon			= HUTAO.IMG_PATH.."corpse-icon.png",
		icon_mipmaps	= 1,
		icon_size		= 128,
	},
}

HUTAO.protos.corpse.pictures = {
	layers = {
		{
			filename = HUTAO.IMG_PATH.."corpse.png",
			frame_count = 2,
			size = 160,
			shift = util.by_pixel(0.0, -2.0),
			hr_version = {
				filename = HUTAO.IMG_PATH.."hr-corpse.png",
				frame_count = 2,
				size = 320,
				scale = 0.5,
				shift = util.by_pixel(0.0, -2.0),
			},
		},
		{
			filename = HUTAO.IMG_PATH.."corpse-shadow.png",
			draw_as_shadow = true,
			frame_count = 2,
			size = 160,
			shift = util.by_pixel(0.0, -2.0),
			hr_version = {
				filename = HUTAO.IMG_PATH.."hr-corpse-shadow.png",
				draw_as_shadow = true,
				frame_count = 2,
				size = 320,
				scale = 0.5,
				shift = util.by_pixel(0.0, -2.0),
			},
		},
	},
}

CharModHelper.create_prototypes(HUTAO.protos)

HUTAO.entered_file("leave")
