HUTAO.entered_file()

local corpse = data.raw["character-corpse"][HUTAO.protos.corpse.name]

corpse.armor_picture_mapping = {}
for a_name, armor in pairs(data.raw.armor) do
	corpse.armor_picture_mapping[a_name] = 1
	HUTAO.writeDebug("Changed armor_picture_mapping of \"%s\" for \"%s\": %s",
					{corpse.name, a_name, corpse.armor_picture_mapping[a_name]})
end
HUTAO.protos.corpse.armor_picture_mapping = table.deepcopy(corpse.armor_picture_mapping)

HUTAO.entered_file("leave")
