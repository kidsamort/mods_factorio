require("functions")

local initial_multiplier = settings.startup[ProductivityResearchForEveryone.prefix("cost_multiplier_initial")].value
local step_multiplier = settings.startup[ProductivityResearchForEveryone.prefix("cost_multiplier_step")].value

-- Find the most basic technology to copy for stuff that is unlocked by default
local technologies = data.raw["technology"]

ProductivityResearchForEveryone.buildPrerequisitesWithoutTriggers(technologies)

local most_basic_technology = nil
for key, val in pairs(technologies) do
    if (val.enabled ~= false) and val.unit and val.unit.count then
        if not most_basic_technology then
            most_basic_technology = val
        end
        if ProductivityResearchForEveryone.isTechSimplerThan(val, most_basic_technology) then
            most_basic_technology = val
        end
    end
end

-- For each technology, compute the most expensive prerequisite if it is a trigger technology or itself if it is not
local unlock_technology = {}
for key, val in pairs(technologies) do
    if val.enabled ~= false then
        if val.unit then
            unlock_technology[key] = val
        else
            unlock_technology[key] = nil
            for _, prereq in pairs(ProductivityResearchForEveryone.prereq_list[key]) do
                if not unlock_technology[key] then
                    unlock_technology[key] = technologies[prereq]
                end
                if ProductivityResearchForEveryone.isTechSimplerThan(unlock_technology[key], technologies[prereq]) then
                    unlock_technology[key] = technologies[prereq]
                end
            end
        end

        if not unlock_technology[key] then
            unlock_technology[key] = most_basic_technology
        end
    end
end

-- For each recipe, find the simplest 'unlock-technology' that unlocks it
-- Also find recipes that have productivity already
local recipe_unlock = {}
local recipe_productivity_exists = {}
for key, val in pairs(technologies) do
    if (val.enabled ~= false) and val.effects then
        for _, effect in pairs(val.effects) do
            if effect.type == "unlock-recipe" then
                local recipe = effect.recipe
                if not recipe_unlock[recipe] then
                    recipe_unlock[recipe] = val
                end
                if ProductivityResearchForEveryone.isTechSimplerThan(unlock_technology[key], unlock_technology[recipe_unlock[recipe].name]) then
                    recipe_unlock[recipe] = val
                end
            end
            if effect.type == "change-recipe-productivity" then
                recipe_productivity_exists[effect.recipe] = true
            end
        end
    end
end

-- Iterate over recipes and create technologies
for key, val in pairs(data.raw["recipe"]) do
    if ProductivityResearchForEveryone.isProductiveRecipe(val) and not recipe_productivity_exists[key] then
        local prereq = nil
        if val.enabled == false then
            prereq = recipe_unlock[key]
        end

        if (val.enabled ~= false) or prereq then
            local copy_tech_object = most_basic_technology
            if prereq and unlock_technology[prereq.name] then
                copy_tech_object = unlock_technology[prereq.name]
            end
        
            local max_recipe_productivity = 3.0
            if val.maximum_productivity then
                max_recipe_productivity = val.maximum_productivity
            end

            local tech_object = {
                type = "technology",
                name = ProductivityResearchForEveryone.prefix(key .. "-productivity") .. "-1",
                upgrade = true,
                max_level = math.ceil(max_recipe_productivity * 10),
                effects = {
                    {
                        type = "change-recipe-productivity",
                        recipe = key,
                        change = 0.1
                    }
                }
            }

            -- Localised name
            if val.localised_name then
                tech_object.localised_name = {"technology-name." .. ProductivityResearchForEveryone.prefix("productivity"), ProductivityResearchForEveryone.tableDeepcopy(val.localised_name)}
            else
                local recipe_loc = {"?", {"recipe-name." .. key}}
                if val.main_product then
                    table.insert(recipe_loc, {"item-name." .. val.main_product})
                    local item = ProductivityResearchForEveryone.getItemPrototype(val.main_product)
                    if item and item.place_result then
                        table.insert(recipe_loc, {"entity-name." .. item.place_result})
                    end
                end
                if val.results and #val.results > 0 then
                    table.insert(recipe_loc, {val.results[1].type .. "-name." .. val.results[1].name})
                    local item = ProductivityResearchForEveryone.getItemPrototype(val.results[1].name)
                    if item and item.place_result then
                        table.insert(recipe_loc, {"entity-name." .. item.place_result})
                    end
                end
                tech_object.localised_name = {"technology-name." .. ProductivityResearchForEveryone.prefix("productivity"), recipe_loc}
            end

            -- Unit
            tech_object.unit = {
                ingredients = ProductivityResearchForEveryone.tableDeepcopy(copy_tech_object.unit.ingredients),
                time = copy_tech_object.unit.time
            }
            if copy_tech_object.unit.count then
                tech_object.unit.count_formula = step_multiplier .. "^(L-1)*" .. (copy_tech_object.unit.count * initial_multiplier)
            else
                tech_object.unit.count_formula = step_multiplier .. "^(L-1)*" .. initial_multiplier .. "*" .. copy_tech_object.unit.count_formula
            end

            -- Prerequisites
            if prereq then
                tech_object.prerequisites = {prereq.name}
            end

            -- Icon
            if val.icons or val.icon then
                tech_object.icons = ProductivityResearchForEveryone.getPrototypeIcons(val)
            else 
                if val.main_product and val.main_product ~= "" then
                    tech_object.icons = ProductivityResearchForEveryone.getPrototypeIcons(ProductivityResearchForEveryone.getItemPrototype(val.main_product))
                else
                    if val.results[1].type == "item" then
                        tech_object.icons = ProductivityResearchForEveryone.getPrototypeIcons(ProductivityResearchForEveryone.getItemPrototype(val.results[1].name))
                    else
                        tech_object.icons = ProductivityResearchForEveryone.getPrototypeIcons(data.raw[val.results[1].type][val.results[1].name])
                    end
                end
            end
            table.insert(tech_object.icons, {icon = "__core__/graphics/icons/technology/effect-constant/effect-constant-recipe-productivity.png", icon_size = 64})
            ProductivityResearchForEveryone.rescaleIcons(tech_object.icons, 4) -- display fix

            data:extend({tech_object})
        end
    end
end