require("functions")

data:extend({
    {
        type = "double-setting",
        name = ProductivityResearchForEveryone.prefix("cost_multiplier_initial"),
        setting_type = "startup",
        default_value = 10.0,
        order = "a-a"
    },
    {
        type = "double-setting",
        name = ProductivityResearchForEveryone.prefix("cost_multiplier_step"),
        setting_type = "startup",
        default_value = 1.5,
        order = "a-b"
    },
    {
        type = "bool-setting",
        name = ProductivityResearchForEveryone.prefix("skip_recycling_barreling"),
        setting_type = "startup",
        default_value = true,
        order = "a-c"
    }
})