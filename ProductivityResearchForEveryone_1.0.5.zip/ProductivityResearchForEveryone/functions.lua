ProductivityResearchForEveryone = {}

function ProductivityResearchForEveryone.prefix(name)
    return "sem-prfe_" .. name
end

function ProductivityResearchForEveryone.tableDeepcopy(tbl)
    if type(tbl) ~= "table" then
        return tbl
    end
    local new_tbl = {}
    for key, val in pairs(tbl) do
        new_tbl[key] = ProductivityResearchForEveryone.tableDeepcopy(val)
    end
    return new_tbl
end

function ProductivityResearchForEveryone.getPrototypeIcons(prototype)
    if not prototype then
        return nil
    end
    if prototype.icons then
        return ProductivityResearchForEveryone.tableDeepcopy(prototype.icons)
    else
        return {
                {
                icon = prototype.icon,
                icon_size = prototype.icon_size
            }
        }
    end
end

function ProductivityResearchForEveryone.rescaleIcons(icons, rescale_mod)
    for _, icon in pairs(icons) do
        if icon.scale then
            icon.scale = icon.scale * rescale_mod
            if icon.shift then
                icon.shift[1] = icon.shift[1] * rescale_mod
                icon.shift[2] = icon.shift[2] * rescale_mod
            end
        end
    end
end

function ProductivityResearchForEveryone.getItemPrototype(name)
    local item_categories = {"item", "ammo", "capsule", "gun", "item-with-entity-data", "item-with-label", "item-with-inventory", "blueprint-book", "item-with-tags", "selection-tool", "blueprint", "copy-paste-tool", "deconstruction-item", "spidertron-remote", "upgrade-item", "module", "rail-planner", "space-platform-starter-pack", "tool", "armor", "repair-tool", "fluid"}
    for _, cat in pairs(item_categories) do
        if data.raw[cat] and data.raw[cat][name] then
            return data.raw[cat][name]
        end
    end
end

function ProductivityResearchForEveryone.buildPrerequisitesWithoutTriggers(technologies)
    ProductivityResearchForEveryone.prereq_list = {}
    local prereq_relation = {}
    local postreq_relation = {}
    for key, val in pairs(technologies) do
        prereq_relation[key] = {}
        postreq_relation[key] = {}
    end

    for key, val in pairs(technologies) do
        if val.prerequisites then
            for _, prereq in pairs(val.prerequisites) do
                log(prereq .. "->" .. key)
                if technologies[prereq] then
                    prereq_relation[key][prereq] = true
                    postreq_relation[prereq][key] = true
                end
            end
        end
    end

    -- Sequentially discard all trigger techs
    for key, val in pairs(technologies) do
        if not val.unit then
            for postreq, _ in pairs(postreq_relation[key]) do
                for prereq, _ in pairs(prereq_relation[key]) do
                    prereq_relation[postreq][prereq] = true
                    postreq_relation[prereq][postreq] = true
                end
            end
        end
    end

    -- Build the prereq list
    for key, val in pairs(technologies) do
        if (val.enabled or true) then
            ProductivityResearchForEveryone.prereq_list[key] = {}
            for prereq, _ in pairs(prereq_relation[key]) do
                if technologies[prereq].unit then
                    table.insert(ProductivityResearchForEveryone.prereq_list[key], prereq)
                end
            end
        end
    end
end

function ProductivityResearchForEveryone.isTechSimplerThan(tech, other_tech)
    -- ignore disabled techs
    if (tech.enabled ~= false) and not (other_tech.enabled ~= false) then
        return true
    end
    if not (tech.enabled ~= false) and (other_tech.enabled ~= false) then
        return false
    end

    -- ignore trigger techs
    if tech.unit and not other_tech.unit then
        return true
    end
    if not tech.unit and other_tech.unit then
        return false
    end

    -- bias towards technologies with no prerequisites
    if #ProductivityResearchForEveryone.prereq_list[tech.name] == 0 and #ProductivityResearchForEveryone.prereq_list[other_tech.name] > 0 then
        return true
    end
    if #ProductivityResearchForEveryone.prereq_list[tech.name] > 0 and #ProductivityResearchForEveryone.prereq_list[other_tech.name] == 0 then
        return false
    end

    -- order by pack type count
    if #tech.unit.ingredients ~= #other_tech.unit.ingredients then
        return #tech.unit.ingredients < #other_tech.unit.ingredients
    end

    -- order by pack amount
    -- ignore count formulas
    if tech.unit.count and not other_tech.unit.count then
        return true
    end
    if not tech.unit.count and other_tech.unit.count then
        return false
    end
    if tech.unit.count ~= other_tech.unit.count then
        return tech.unit.count < other_tech.unit.count
    end

    -- order by pack research time
    if tech.unit.time ~= other_tech.unit.time then
        return tech.unit.time < other_tech.unit.time
    end

    -- order by prerequisites count
    if #ProductivityResearchForEveryone.prereq_list[tech.name] ~= #ProductivityResearchForEveryone.prereq_list[other_tech.name] then
        return #ProductivityResearchForEveryone.prereq_list[tech.name] < #ProductivityResearchForEveryone.prereq_list[other_tech.name]
    end

    -- default to false
    return false
end

function ProductivityResearchForEveryone.startswith(str, start)
    return string.sub(str, 1, string.len(start)) == start
end

function ProductivityResearchForEveryone.isProductiveRecipe(recipe)
    if recipe.parameter then
        return false
    end
    if not recipe.allow_productivity then
        return false
    end
    if settings.startup[ProductivityResearchForEveryone.prefix("skip_recycling_barreling")].value then
        if recipe.subgroup == "fill-barrel" or recipe.subgroup == "empty-barrel" or recipe.category == "recycling" then
            return false
        end
    end
    return true
end