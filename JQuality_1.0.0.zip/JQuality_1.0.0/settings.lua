
local boost_multiplier = {
    type = "double-setting",
    name = "JQuality-handcrafting-green-probability",
    setting_type = "startup",
    minimum_value = 1,
    default_value = 100,
    maximum_value = 100000
}
data:extend{boost_multiplier}
