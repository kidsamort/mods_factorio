
data.raw["quality"]["uncommon"].icon = "__JQuality__/assets/quality-uncommon.png"
data.raw["quality"]["rare"].icon = "__JQuality__/assets/quality-rare.png"
data.raw["quality"]["epic"].icon = "__JQuality__/assets/quality-epic.png"
data.raw["quality"]["legendary"].icon = "__JQuality__/assets/quality-legendary.png"
