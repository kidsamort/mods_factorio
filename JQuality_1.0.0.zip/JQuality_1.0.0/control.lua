--control.lua

script.on_event(defines.events.on_player_crafted_item,
    function(event)
        local probability = settings.startup["JQuality-handcrafting-green-probability"].value
        randomValue = math.random(probability)
        if randomValue == probability then
            local stack = event.item_stack --Because I don't like indexing to the same place multiple times
            if stack.quality ~= nil and stack.quality.next ~= nil then
                -- literally just recreate the whole item with then next quality tier because I
                -- can't just do "set_quality" or "increment_quality" :O
                stackData = {
                    valid_for_read = stack.valid_for_read,
                    prototype = stack.prototype,
                    name = stack.name,
                    type = stack.type,
                    count = stack.count,
                    health = stack.health,
                    quality = stack.quality.next.name,
                    spoil_tick = stack.spoil_tick,
                    spoil_percent = stack.spoil_percent,
                    item = stack.item,
                    is_module = stack.is_module,
                    object_name = stack.object_name,

                    is_blueprint = stack.is_blueprint,
                    is_blueprint_book = stack.is_blueprint_book,
                    is_item_with_label = stack.is_item_with_label,
                    is_item_with_inventory = stack.is_item_with_inventory,
                    is_item_with_entity_data = stack.is_item_with_entity_data,
                    is_selection_tool = stack.is_selection_tool,
                    is_item_with_tags = stack.is_item_with_tags,
                    is_deconstruction_item = stack.is_deconstruction_item,
                    is_upgrade_item = stack.is_upgrade_item,
                    is_tool = stack.is_tool,
                    is_ammo = stack.is_ammo,
                    is_armor = stack.is_armor,
                    is_repair_tool = stack.is_repair_tool,
                    item_number = stack.item_number,
                    preview_icons = stack.preview_icons,
                    grid = stack.grid,
                    owner_location = stack.owner_location,

                    blueprint_snap_to_grid = nil,
                    blueprint_position_relative_to_grid = nil,
                    blueprint_absolute_snapping = nil,
                    cost_to_build = nil,
                    default_icons = nil,
                    active_index = nil,
                    label = nil,
                    label_color = nil,
                    allow_manual_label_change = nil,
                    entity_label = nil,
                    entity_color = nil,
                    tags = nil,
                    custom_description = nil,
                    entity_filter_count = nil,
                    entity_filters = nil,
                    tile_filter_count = nil,
                    tile_filters = nil,
                    entity_filter_mode = nil,
                    tile_filter_mode = nil,
                    tile_selection_mode = nil,
                    trees_and_rocks_only = nil,
                    mapper_count = nil,
                    durability = nil,
                    ammo = nil
                }
                if stack.is_blueprint then
                    stackData.blueprint_snap_to_grid = stack.blueprint_snap_to_grid
                    stackData.blueprint_position_relative_to_grid = stack.blueprint_position_relative_to_grid
                    stackData.blueprint_absolute_snapping = stack.blueprint_absolute_snapping
                    stackData.cost_to_build = stack.cost_to_build
                    stackData.default_icons = stack.default_icons
                    stackData.active_index = stack.active_index
                end
                if stack.is_item_with_label then
                    stackData.label = stack.label
                    stackData.label_color = stack.label_color
                    stackData.allow_manual_label_change = stack.allow_manual_label_change
                end
                if stack.is_item_with_entity_data then
                    stackData.entity_label = stack.entity_label
                    stackData.entity_color = stack.entity_color
                end
                if stack.is_item_with_tags then
                    stackData.tags = stack.tags
                    stackData.custom_description = stack.custom_description
                end
                if stack.is_deconstruction_item then
                    stackData.entity_filter_count = stack.entity_filter_count
                    stackData.entity_filters = stack.entity_filters
                    stackData.tile_filter_count = stack.tile_filter_count
                    stackData.tile_filters = stack.tile_filters
                    stackData.entity_filter_mode = stack.entity_filter_mode
                    stackData.tile_filter_mode = stack.tile_filter_mode
                    stackData.tile_selection_mode = stack.tile_selection_mode
                    stackData.trees_and_rocks_only = stack.trees_and_rocks_only
                end
                if stack.is_upgrade_item then
                    stackData.mapper_count = stack.mapper_count
                end
                if stack.is_tool then
                    stackData.durability = stack.durability
                end
                if stack.is_ammo then
                    stackData.ammo = stack.ammo
                end
                stack.set_stack({
                    valid_for_read = stack.valid_for_read,
                    prototype = stack.prototype,
                    name = stack.name,
                    type = stack.type,
                    count = stack.count,
                    health = stack.health,
                    quality = stack.quality.next.name,
                    spoil_tick = stack.spoil_tick,
                    spoil_percent = stack.spoil_percent,
                    item = stack.item,
                    is_module = stack.is_module,
                    object_name = stack.object_name,

                    is_blueprint = stack.is_blueprint,
                    is_blueprint_book = stack.is_blueprint_book,
                    is_item_with_label = stack.is_item_with_label,
                    is_item_with_inventory = stack.is_item_with_inventory,
                    is_item_with_entity_data = stack.is_item_with_entity_data,
                    is_selection_tool = stack.is_selection_tool,
                    is_item_with_tags = stack.is_item_with_tags,
                    is_deconstruction_item = stack.is_deconstruction_item,
                    is_upgrade_item = stack.is_upgrade_item,
                    is_tool = stack.is_tool,
                    is_ammo = stack.is_ammo,
                    is_armor = stack.is_armor,
                    is_repair_tool = stack.is_repair_tool,
                    item_number = stack.item_number,
                    preview_icons = stack.preview_icons,
                    grid = stack.grid,
                    owner_location = stack.owner_location,

                    blueprint_snap_to_grid = nil,
                    blueprint_position_relative_to_grid = nil,
                    blueprint_absolute_snapping = nil,
                    cost_to_build = nil,
                    default_icons = nil,
                    active_index = nil,
                    label = nil,
                    label_color = nil,
                    allow_manual_label_change = nil,
                    entity_label = nil,
                    entity_color = nil,
                    tags = nil,
                    custom_description = nil,
                    entity_filter_count = nil,
                    entity_filters = nil,
                    tile_filter_count = nil,
                    tile_filters = nil,
                    entity_filter_mode = nil,
                    tile_filter_mode = nil,
                    tile_selection_mode = nil,
                    trees_and_rocks_only = nil,
                    mapper_count = nil,
                    durability = nil,
                    ammo = nil
                })
            end
        end
    end
)
