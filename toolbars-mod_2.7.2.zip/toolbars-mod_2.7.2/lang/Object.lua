---@class Object
Object = {}

---[static]
---@generic C : Object
---@return C
function Object:new()
    return Object:super({ __className = "lang.Object" })
end

---[static]
---@generic C : Object
---@param className string
---@return C
function Object:extendAs(className)
    return setmetatable({ __className = className },
            { __index = self,
              __tostring = function(object)
                  return object:toString()
              end
            })
end

---[static]
---@generic O : Object
---@param super O @instance of super class
---@return self @instance of self class
function Object:super(super)
    -- self == class
    super.__className = self.__className
    return setmetatable(super, { __index = self })
end

---@public
---@generic T : Object
---@param class T
---@return boolean
function Object:isInstanceOf(class)
    return self:class() == class
end

---@public
---@generic T : Object
---@param class T
---@return T
function Object:castTo(class)
    assert(self:isInstanceOf(class))
    return self
end

---@generic C : Object
---@return C
function Object:class()
    return getmetatable(self).__index
end

---@public
---@return string
function Object:className()
    return self.__className
end

---@public
---@return string
function Object:toString()
    return serpent.line(self, { comment = false })
end
--
--A = Object:extendAs("A")
--function A:new()
--    return A:super(Object:new())
--end
--function A:pies()
--    print("A pies")
--end
--
--B = A:extendAs("B")
--function B:new()
--    return B:super(A:new())
--end
--
--C = B:extendAs("C")
--function C:new()
--    return C:super(B:new())
--end
--
--D = C:extendAs("D")
--function D:new()
--    return D:super(C:new())
--end
--
--function D:pies()
--    print("D pies")
--end
--
--local d = D:new()
--d:pies()
--D:pies()
--assert(D:className() == "D")
