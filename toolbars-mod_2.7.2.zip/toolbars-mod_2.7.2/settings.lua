data:extend({
    {
        type = "bool-setting",
        name = "show-controls-in-the-tooltip",
        localised_name = "Show controls in the tooltip",
        setting_type = "runtime-per-user",
        default_value = true,
        order = "a"
    }
})
