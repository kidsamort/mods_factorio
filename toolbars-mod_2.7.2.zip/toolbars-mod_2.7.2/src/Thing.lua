---@class Thing : Object
---@field private _name string
Thing = Object:extendAs("Thing")

---@public
---@param name string
function Thing:new(name)
    local this = Thing:super(Object:new())
    this._name = assert(name)
    return this
end

---@public
---@return string
function Thing:name()
    return self._name
end

---@param other Thing
function Thing:equals(other)
    return self._name == other._name
end
