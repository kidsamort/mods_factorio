import("Thing")

---@class Item : Thing
Item = Thing:extendAs("Item")

---@public
---@param name string
---@param quality string
function Item:new(name, quality)
    local this = Item:super(Thing:new(name))
    this._quality = quality and quality or "normal"
    return this
end

---@public
---@return string
function Item:quality()
    return self._quality
end

---@param other Item
function Item:equals(other)
    return self:name() == other:name() and self:quality() == other:quality()
end

---@public
---@return ItemIDAndQualityIDPair
function Item:nameQualityPair()
    return { name = self:name(), quality = self:quality() }
end
