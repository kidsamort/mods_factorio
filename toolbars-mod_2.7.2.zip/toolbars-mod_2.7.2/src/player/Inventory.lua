import("Item")
import("player.Content")
import("player.EventBus")
import("player.events.CursorStackChanged")
import("player.events.InventoryChanged")
import("player.events.InventoryContentChanged")

---@class Inventory : Object
---@field private _luaPlayer LuaPlayer
---@field private _content Content
---@field private _upToDate boolean
Inventory = Object:extendAs("player.Inventory")

---@private
---@param luaPlayer LuaPlayer
---@param eventBus EventBus
---@param cursor Cursor
---@return Inventory
function Inventory:new(luaPlayer, eventBus, cursor)
    local this = Inventory:super(Object:new())
    this._luaPlayer = luaPlayer
    this._eventBus = eventBus
    this._cursor = cursor
    this._content = this:content()
    this._upToDate = true
    this._eventBus:subscribeTo(CursorStackChanged, this)
    this._eventBus:subscribeTo(InventoryChanged, this)
    return this
end

---@param event CursorStackChanged | InventoryChanged
function Inventory:handle(event)
    self._upToDate = false
end

function Inventory:refresh()
    if (self:isPersonal() and not self._upToDate) or self:isLogistic() then
        local freshContent = self:content()
        if not self._content:equals(freshContent) then
            self._content = freshContent
            self._eventBus:publish(InventoryContentChanged:new())
        end
    end
    self._upToDate = true
end

---@private
---@return Content
function Inventory:content()
    local content = Content:new()
    if self:isPersonal() then
        content:addAll(self:mainContent())
        content:addAll(self:trashContent())
    elseif self:isLogistic() then
        local networks = self._luaPlayer.surface.find_logistic_networks_by_construction_area(self._luaPlayer.position, self._luaPlayer.force)
        for _, network in ipairs(networks) do
            content:addAll(network.get_contents())
        end
        if self._luaPlayer.surface.platform and self._luaPlayer.surface.platform.hub then
            content:addAll(self._luaPlayer.surface.platform.hub.get_output_inventory().get_contents())
        end
    end
    return content
end

---@public
---@return boolean
function Inventory:isPersonal()
    local controllerType = self._luaPlayer.controller_type
    return controllerType == defines.controllers.character
            or controllerType == defines.controllers.editor
end

---@public
---@return boolean
function Inventory:isLogistic()
    return self._luaPlayer.controller_type == defines.controllers.remote
end

---@private
---@return ItemCountWithQuality[]
function Inventory:mainContent()
    if self:hasMain() then
        return self:main().get_contents()
    else
        return {}
    end
end

---@private
---@return ItemCountWithQuality[]
function Inventory:trashContent()
    if self:hasTrash() then
        return self:trash().get_contents()
    else
        return {}
    end
end

---@public
---@param item Item
function Inventory:pick(item)
    if self:isPersonal() and self:hasItem(item) then
        self:pickStack(item)
    else
        self:pickGhost(item)
    end
end

---@private
---@param item Item
---@return boolean
function Inventory:hasItem(item)
    return self:count(item) > 0
end

---@public
---@param item Item
---@return number
function Inventory:count(item)
    return self._content:count(item)
end

---@private
---@param item Item
function Inventory:pickStack(item)
    local stack, slotIndex, inventory = self:findStack(item)
    local successful = self._cursor:pickStack(stack)
    if successful then
        self._luaPlayer.hand_location = { inventory = inventory.index, slot = slotIndex }
    end
end

---@public
---@param item Item
---@return LuaItemStack, number, LuaInventory
function Inventory:findStack(item)
    local stack, slotIndex, inventory
    if self:hasTrash() and self:trash().get_item_count(item:nameQualityPair()) > 0 then
        stack, slotIndex = self:trash().find_item_stack(item:nameQualityPair())
        inventory = self:trash()
    else
        stack, slotIndex = self:main().find_item_stack(item:nameQualityPair())
        inventory = self:main()
    end
    return stack, slotIndex, inventory
end

---@private
---@return boolean
function Inventory:hasMain()
    return self:main() ~= nil
end

---@private
---@return LuaInventory
function Inventory:main()
    return self._luaPlayer.get_main_inventory()
end

---@private
---@return boolean
function Inventory:hasTrash()
    return self:trash() ~= nil
end

---@private
---@return LuaInventory
function Inventory:trash()
    return self._luaPlayer.get_inventory(defines.inventory.character_trash)
end

---@private
---@param item Item
function Inventory:pickGhost(item)
    self._cursor:pickGhost(item)
end
