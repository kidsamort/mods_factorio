---@class Content : Object
---@field private _content table<string, table<string, number>>
Content = Object:extendAs("player.Content")

---@public
function Content:new()
    local this = Content:super(Object:new())
    this._content = {}
    return this
end

---@public
---@param itemCounts ItemCountWithQuality[]
function Content:addAll(itemCounts)
    for _, itemCount in ipairs(itemCounts) do
        self:add(itemCount)
    end
end

---@public
---@param itemCount ItemCountWithQuality
function Content:add(itemCount)
    local name = itemCount.name
    local qualityName = (type(itemCount.quality) == "string" and itemCount.quality or itemCount.quality.name)
    if self._content[name] then
        if self._content[name][qualityName] then
            self._content[name][qualityName] = self._content[name][qualityName] + itemCount.count
        else
            self._content[name][qualityName] = itemCount.count
        end
    else
        self._content[name] = {}
        self._content[name][qualityName] = itemCount.count
    end
end

---@public
---@param item Item
---@return number
function Content:count(item)
    if self._content[item:name()] and self._content[item:name()][item:quality()] then
        return self._content[item:name()][item:quality()]
    else
        return 0
    end
end

---@public
---@param other Content
---@return boolean
function Content:equals(other)
    return self:contains(other) and other:contains(self)
end

---@public
---@param other Content
---@return boolean
function Content:contains(other)
    local this = self._content
    for name, qualities in pairs(other._content) do
        if this[name] == nil then
            return false
        else
            for key, value in pairs(qualities) do
                if this[name][key] == nil then
                    return false
                else
                    if this[name][key] ~= value then
                        return false
                    end
                end
            end
        end
    end
    return true
end
