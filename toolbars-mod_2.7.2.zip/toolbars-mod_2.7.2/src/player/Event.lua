---@class Event : Object
Event = Object:extendAs("player.Event")

function Event:new()
    return Event:super(Object:new())
end
