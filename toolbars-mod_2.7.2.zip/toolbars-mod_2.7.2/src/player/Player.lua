import("gui.Screen")
import("player.Cursor")
import("player.EventBus")
import("player.Inventory")

---@class Player : Object
---@field private __gameJustStarted boolean
---@field private __instances table<number, Player>
---@field private _luaPlayer LuaPlayer
---@field private _cursor Cursor
---@field private _screen Screen
---@field private _inventory Inventory
---@field private _eventBus EventBus
Player = Object:extendAs("player.Player")
Player.__instances = {}

function Player:loadAllPlayers()
    for _, luaPlayer in ipairs(game.connected_players) do
        Player:get(luaPlayer.index)
    end
end

---@public
---@param player_index number
function Player:reload(player_index)
    Player:invalidate(player_index)
    Player:get(player_index)
end

---@public
---@param player_index number
function Player:invalidate(player_index)
    Player.__instances[player_index] = nil
end

---@public
---@param player_index number
---@return Player
function Player:get(player_index)
    assert(player_index)
    local current = Player.__instances[player_index]
    if not current or not current._luaPlayer.valid then
        Player.__instances[player_index] = Player:new(game.get_player(player_index))
        Player.__instances[player_index]:load()
    end
    return Player.__instances[player_index]
end

---@public
---@return Player[]
function Player:getAll()
    return Player.__instances
end

---@public
---@param luaPlayer LuaPlayer
function Player:new(luaPlayer)
    local this = Player:super(Object:new())
    this._luaPlayer = luaPlayer
    this._eventBus = EventBus:new()
    this._cursor = Cursor:new(this._luaPlayer)
    this._screen = Screen:new(this._luaPlayer)
    this._inventory = Inventory:new(this._luaPlayer, this._eventBus, this._cursor)
    return this
end

---@private
function Player:load()
    self._screen:load()
end

---@public
function Player:createToolbar()
    self._screen:createToolbar()
end

---@public
function Player:showToolbars()
    self._screen:show()
end

---@public
function Player:hideToolbars()
    self._screen:hide()
end

---@public
---@param click Click
function Player:handleClick(click)
    self._screen:handleClick(click)
end

---@public
---@param changeEvent ChangedEvent
function Player:handleChange(changeEvent)
    self._screen:handleChange(changeEvent)
end

function Player:handleHover(hovered)
    self._screen:handleHover(hovered)
end

function Player:handleLeave(left)
    self._screen:handleLeave(left)
end

---@param event Event
function Player:handle(event)
    self._eventBus:publish(event)
end

---@public
function Player:refreshInventory()
    self._inventory:refresh()
end

---@public
---@return EventBus
function Player:eventBus()
    return self._eventBus
end

---@public
---@return Cursor
function Player:cursor()
    return self._cursor
end

---@public
---@return Inventory
function Player:inventory()
    return self._inventory
end
