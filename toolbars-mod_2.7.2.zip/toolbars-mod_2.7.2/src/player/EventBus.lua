---@class EventBus : Object
---@field private _topics table<Event, table<Subscriber>>
EventBus = Object:extendAs("player.EventBus")

function EventBus:new()
    local this = EventBus:super(Object:new())
    this._topics = {}
    return this
end

---@public
---@param event Event
function EventBus:publish(event)
    local subscribers = self._topics[event:className()]
    if subscribers then
        for _, subscriber in ipairs(subscribers) do
            subscriber:handle(event)
        end
    end
end

---@public
---@param eventClass Event
---@param subscriber Subscriber
function EventBus:subscribeTo(eventClass, subscriber)
    local eventClassName = eventClass:className()
    if not self._topics[eventClassName] then
        self._topics[eventClassName] = {}
    end
    table.insert(self._topics[eventClassName], subscriber)
end

---@public
---@param eventClass Event
---@param toUnsubscribe Subscriber
function EventBus:unsubscribeFrom(eventClass, toUnsubscribe)
    local topic = self._topics[eventClass:className()]
    if topic then
        for i, registered in ipairs(topic) do
            if registered == toUnsubscribe then
                table.remove(topic, i)
            end
        end
    end
end

---@public
---@param toUnsubscribe Subscriber
function EventBus:unsubscribeFromAll(toUnsubscribe)
    for _, topic in pairs(self._topics) do
        for i, registered in ipairs(topic) do
            if registered == toUnsubscribe then
                table.remove(topic, i)
            end
        end
    end
end

---@class Subscriber
Subscriber = {}

---@public
---@param event Event
function Subscriber:handle(event)
end
