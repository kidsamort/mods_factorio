import("player.Event")

---@class CursorStackChanged : Event
CursorStackChanged = Event:extendAs("player.events.CursorStackChanged")

function CursorStackChanged:new()
    return CursorStackChanged:super(Event:new())
end
