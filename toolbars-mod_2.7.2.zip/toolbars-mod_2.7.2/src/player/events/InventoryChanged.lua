import("player.Event")

---@class InventoryChanged : Event
InventoryChanged = Event:extendAs("player.events.InventoryChanged")

function InventoryChanged:new()
    return InventoryChanged:super(Event:new())
end
