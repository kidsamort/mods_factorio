import("player.Event")

---@class InventoryContentChanged : Event
InventoryContentChanged = Event:extendAs("player.events.InventoryContentChanged")

function InventoryContentChanged:new()
    return InventoryContentChanged:super(Event:new())
end
