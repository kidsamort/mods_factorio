import("player.Event")

---@class Nothing : Event
---@field _eventData EventData
Nothing = Event:extendAs("player.events.controls.Nothing")

function Nothing:new()
    return Nothing:super(Event:new())
end
