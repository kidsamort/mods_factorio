import("player.Event")

---@class Pick : Event
---@field _eventData EventData
Pick = Event:extendAs("player.events.controls.Pick")

function Pick:new()
    return Pick:super(Event:new())
end
