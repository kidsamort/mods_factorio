import("player.Event")

---@class Clear : Event
---@field _eventData EventData
Clear = Event:extendAs("player.events.controls.Clear")

function Clear:new()
    return Clear:super(Event:new())
end
