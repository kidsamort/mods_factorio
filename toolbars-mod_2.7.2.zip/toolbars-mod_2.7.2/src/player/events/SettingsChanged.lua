import("player.Event")

---@class SettingsChanged : Event
SettingsChanged = Event:extendAs("player.events.SettingsChanged")

function SettingsChanged:new()
    return SettingsChanged:super(Event:new())
end
