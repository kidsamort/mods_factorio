import("gui.Component")
import("gui.toolbar.content.AddSection")
import("gui.toolbar.content.sections.Sections")

---@class ToolbarContent : Component
ToolbarContent = Component:extendAs("gui.toolbar.content.Content")

function ToolbarContent:create(parent)
    local instance = Component.create(self, parent, {
        type = "scroll-pane",
        direction = "vertical",
        vertical_scroll_policy = "auto",
        style = "toolbar_content" })
    Sections:create(instance)
    AddSection:create(instance)
    return instance
end

---@public
---@return ToolbarContent
---@param root LuaGuiElement
function ToolbarContent:new(parent, root)
    return ToolbarContent:super(Component:new(parent, root))
end

function ToolbarContent:childrenClasses()
    return { Sections, AddSection }
end

---@public
---@return Sections
function ToolbarContent:sections()
    return self:childOfType(Sections)
end

---@public
---@return number
function ToolbarContent:width()
    return self:sections():width() + 4 * 2
end
