import("gui.Component")
import("gui.toolbar.Toolbar")
import("gui.toolbar.content.sections.section.header.SectionHeader")
import("gui.toolbar.content.sections.section.content.SectionContent")

---@class Section : Component
Section = Component:extendAs("gui.toolbar.content.sections.section.Section")

function Section:create(parent)
    local instance = Component.create(self, parent, {
    type = "frame",
    direction = "vertical",
    style = "toolbar_content_sections_section" })
    SectionHeader:create(instance)
    SectionContent:create(instance)
    return instance
end

function Section:new(parent, root)
    return Section:super(Component:new(parent, root))
end

function Section:childrenClasses()
    return { SectionHeader, SectionContent }
end

function Section:moveDown()
    if #self:siblingsAndMe() > self:index() then
        self:parentElement().swap_children(self:index(), self:index() + 1)
    end
end

function Section:moveUp()
    if self:index() > 1 then
        self:parentElement().swap_children(self:index(), self:index() - 1)
    end
end

---@public
function Section:collapse()
    self:content():hide()
end

---@public
function Section:expand()
    self:content():show()
end

---@public
---@return string
function Section:name()
    return self:header():name()
end

---@public
---@return number
function Section:width()
    return self:content():width()
end

function Section:header()
    return self:childOfType(SectionHeader)
end

function Section:content()
    return self:childOfType(SectionContent)
end
