---@class DimOverlay : Component
DimOverlay = Component:extendAs("gui.toolbar.content.sections.section.content.table.slots.item.DimOverlay")

function DimOverlay:create(parent)
    local instance = Component.create(self, parent, {
        type = "button",
        style = "toolbar_content_sections_section_content_table_row_slot_item_overlay_dim",
    })
    instance:root().ignored_by_interaction = true
    return instance
end

function DimOverlay:new(parent, root)
    return DimOverlay:super(Component:new(parent, root))
end
