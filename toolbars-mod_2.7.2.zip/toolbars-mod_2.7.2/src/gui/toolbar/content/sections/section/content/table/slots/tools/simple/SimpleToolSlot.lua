import("gui.toolbar.content.sections.section.content.table.Slot")
import("gui.toolbar.content.sections.section.content.table.slots.tools.simple.SimpleToolButton")
import("player.events.controls.Pick")
import("player.events.CursorStackChanged")

---@private
---@class SimpleToolSlot : Slot
SimpleToolSlot = Slot:extendAs("gui.toolbar.content.sections.section.content.table.slots.tools.simple.SimpleToolSlot")

---@public
---@param parent Component
---@param simpleTool SimpleTool
function SimpleToolSlot:create(parent, simpleTool)
    local instance = Slot.create(self, parent)
    SimpleToolButton:create(instance, simpleTool, { "left", "middle" })
    return instance
end

function SimpleToolSlot:new(parent, root)
    local this = SimpleToolSlot:super(Slot:new(parent, root))
    this:player():eventBus():subscribeTo(CursorStackChanged, this)
    return this
end

function SimpleToolSlot:childrenClasses()
    return { SimpleToolButton }
end

function SimpleToolSlot:controls()
    return { Pick }
end

---@private
---@return SimpleToolButton
function SimpleToolSlot:button()
    return self:childOfType(SimpleToolButton)
end

---@private
---@param event Event
function SimpleToolSlot:handle(event)
    if event:isInstanceOf(CursorStackChanged) then
        self:toggleHighlight()
    elseif event:isInstanceOf(Pick) then
        self:pick()
    end
end

---@private
function SimpleToolSlot:toggleHighlight()
    local cursor = self:player():cursor()
    if cursor:holdsSimpleTool() and cursor:simpleTool():equals(self:simpleTool()) then
        self:button():select()
    else
        self:button():unselect()
    end
end

function SimpleToolSlot:handleClick(click)
    if click:isLeft() then
        self:pick()
    elseif click:isMiddle() then
        self:clear()
    end
end

function SimpleToolSlot:pick()
    self:player():cursor():pickSimpleTool(self:simpleTool())
    self:rememberPick()
end

function SimpleToolSlot:thing()
    return self:simpleTool()
end

---@private
---@return SimpleTool
function SimpleToolSlot:simpleTool()
    return self:button():tool()
end
