---@class ParametersOverlay : Component
ParametersOverlay = Component:extendAs("gui.toolbar.content.sections.section.content.table.slots.tools.parametrized.ParametersOverlay")

---@param parameters table<string>
function ParametersOverlay:create(parent, parameters)
    local instance = Component.create(self, parent, {
        type = "empty-widget",
    })
    return instance
end

function ParametersOverlay:new(parent, root)
    return ParametersOverlay:super(Component:new(parent, root))
end
