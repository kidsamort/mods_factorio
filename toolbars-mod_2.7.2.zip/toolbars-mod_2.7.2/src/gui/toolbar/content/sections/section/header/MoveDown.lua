import("gui.toolbar.content.sections.section.header.SectionHeaderButton")

---@class MoveDown : SectionHeaderButton
MoveDown = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.MoveDown")

function MoveDown:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_move-section-down",
        style = "toolbar_content_sections_section_header_moveDown" })
end

function MoveDown:new(parent, root)
    return MoveDown:super(SectionHeaderButton:new(parent, root))
end

function MoveDown:handleClick(click)
    if click:isLeft() then
        self:section():moveDown()
    end
end

function MoveDown:lock()
    self:hide()
end

function MoveDown:unlock()
    self:show()
end
