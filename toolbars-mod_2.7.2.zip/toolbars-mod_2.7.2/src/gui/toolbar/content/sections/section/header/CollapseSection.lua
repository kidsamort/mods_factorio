import("gui.toolbar.content.sections.section.header.SectionHeaderButton")
import("gui.toolbar.content.sections.section.header.ExpandSection")

---@class CollapseSection : SectionHeaderButton
CollapseSection = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.Collapse")

function CollapseSection:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_collapse",
        style = "toolbar_content_sections_section_header_collapse" })
end

function CollapseSection:new(parent, root)
    return CollapseSection:super(SectionHeaderButton:new(parent, root))
end

function CollapseSection:handleClick(click)
    if click:isLeft() then
        self:section():collapse()
        self:replaceWith(ExpandSection:create(self:parent()))
    end
end
