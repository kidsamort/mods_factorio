import("gui.Component")
import("SimpleTool")

---@class SimpleToolButton : Component
---@field private _tool SimpleTool
SimpleToolButton = Component:extendAs("gui.toolbar.content.sections.section.content.table.slots.tool.SimpleToolButton")

---@param parent Component
---@param simpleTool SimpleTool
---@param mouse_button_filter string[]
function SimpleToolButton:create(parent, simpleTool, mouse_button_filter)
    return Component.create(self, parent, {
        type = "sprite-button",
        elem_tooltip = { type = "item", name = simpleTool:name() },
        sprite = "item/" .. assert(simpleTool:name()),
        style = "toolbar_content_sections_section_content_table_row_slot_button",
        number = nil,
        mouse_button_filter = mouse_button_filter,
        raise_hover_events = true
    })
end

function SimpleToolButton:new(parent, root)
    local this = SimpleToolButton:super(Component:new(parent, root))
    --todo migration: remove after several releases from 2.7.0
    this:root().raise_hover_events = true
    this._tool = SimpleTool:new(this:root().elem_tooltip.name)
end

---@public
---@return SimpleTool
function SimpleToolButton:tool()
    return self._tool
end

---@public
function SimpleToolButton:select()
    self:root().style = "toolbar_content_sections_section_content_table_row_slot_button_selected"
end

---@public
function SimpleToolButton:unselect()
    self:root().style = "toolbar_content_sections_section_content_table_row_slot_button_item"
end
