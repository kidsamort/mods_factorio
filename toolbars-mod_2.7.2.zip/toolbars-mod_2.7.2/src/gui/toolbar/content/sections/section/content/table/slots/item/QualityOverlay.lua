---@class QualityOverlay : Slot
QualityOverlay = Slot:extendAs("gui.toolbar.content.sections.section.content.table.slots.item.QualityOverlay")

---@public
---@param parent Component
---@param qualityName string
---@return QualityOverlay
function QualityOverlay:create(parent, qualityName)
    local overlay = Component.create(self, parent, {
        type = "flow",
        style = "toolbar_content_sections_section_content_table_row_slot_item_overlay_quality"
    })
    overlay:root().ignored_by_interaction = true

    if prototypes.quality[qualityName].draw_sprite_by_default then
        local sprite = Component.create(self, overlay, {
            type = "sprite",
            sprite = "toolbars-mod_quality_" .. qualityName,
            style = "toolbar_content_sections_section_content_table_row_slot_item_overlay_quality_sprite"
        })
        sprite:root().ignored_by_interaction = true
    end
    return overlay
end

function QualityOverlay:new(parent, root)
    return QualityOverlay:super(Slot:new(parent, root))
end
