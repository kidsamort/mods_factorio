import("gui.Component")
import("gui.toolbar.content.sections.section.content.table.slots.empty.EmptySlot")
import("gui.toolbar.content.sections.section.content.table.slots.item.ItemSlot")
import("gui.toolbar.content.sections.section.content.table.slots.tools.simple.SimpleToolSlot")

---@class Row : Component
Row = Component:extendAs("gui.toolbar.content.sections.section.content.table.Row")

function Row:create(parent)
    return Component.create(self, parent, {
        type = "flow",
        direction = "horizontal",
        style = "toolbar_content_sections_section_content_table_row" })
end

---@public
---@return Row
---@param root LuaGuiElement
function Row:new(parent, root)
    return Row:super(Component:new(parent, root))
end

function Row:childrenClasses()
    return { EmptySlot, ItemSlot, SimpleToolSlot }
end

function Row:isOccupied()
    return self:lastOccupiedColumn() > 0
end

---@public
---@param columns number
function Row:setColumns(columns)
    self:trimTo(columns)
    self:fill(columns)
end

---@private
---@param columns number
function Row:trimTo(columns)
    for _, child in ipairs(self:children()) do
        if child:index() > columns then
            child:delete()
        end
    end
end

---@public
---@return number
function Row:lastOccupiedColumn()
    local lastOccupiedSlotIndex = 0
    for _, child in ipairs(self:children()) do
        if not child:isInstanceOf(EmptySlot) then
            lastOccupiedSlotIndex = math.max(lastOccupiedSlotIndex, child:index())
        end
    end
    return lastOccupiedSlotIndex
end

---@private
---@param expectedColumns number
function Row:fill(expectedColumns)
    local missingColumns = expectedColumns - self:columnsCount()
    assert(missingColumns >= 0)
    local i = 0
    while i < missingColumns do
        EmptySlot:create(self)
        i = i + 1
    end
end

---@public
---@return number
function Row:width()
    return self:columnsCount() * 40
end

---@private
---@return number
function Row:columnsCount()
    return #self:slotsRoots()
end

---@private
---@return LuaGuiElement[]
function Row:slotsRoots()
    return self:root().children
end
