import("gui.toolbar.content.sections.section.header.SectionHeaderButton")

---@class DeleteSection : SectionHeaderButton
DeleteSection = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.Delete")

function DeleteSection:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "utility/trash",
        style = "toolbar_content_sections_section_header_delete" })
end

function DeleteSection:new(parent, root)
    return DeleteSection:super(SectionHeaderButton:new(parent, root))
end

function DeleteSection:handleClick(click)
    if click:isLeft() then
        self:header():askForDeletion()
    end
end

function DeleteSection:lock()
    self:hide()
end

function DeleteSection:unlock()
    self:show()
end
