import("gui.Component")
import("gui.toolbar.content.sections.section.Section")
import("gui.toolbar.content.sections.section.header.SectionHeader")

---@class SectionHeaderButton : Component
SectionHeaderButton = Component:extendAs("gui.toolbar.content.sections.section.header.Button")

function SectionHeaderButton:new(parent, root)
    return SectionHeaderButton:super(Component:new(parent, root))
end

---@protected
---@return SectionHeader
function SectionHeaderButton:header()
    return self:findAncestor(SectionHeader)
end

---@protected
---@return Section
function SectionHeaderButton:section()
    return self:findAncestor(Section)
end
