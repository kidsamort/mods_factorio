import("gui.toolbar.content.sections.section.header.SectionHeaderButton")

---@class MoveUp : SectionHeaderButton
MoveUp = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.MoveUp")

function MoveUp:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_move-section-up",
        style = "toolbar_content_sections_section_header_moveUp" })
end

function MoveUp:new(parent, root)
    return MoveUp:super(SectionHeaderButton:new(parent, root))
end

function MoveUp:handleClick(click)
    if click:isLeft() then
        self:section():moveUp()
    end
end

function MoveUp:lock()
    self:hide()
end

function MoveUp:unlock()
    self:show()
end
