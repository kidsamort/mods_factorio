import("player.events.CursorStackChanged")
import("player.events.InventoryContentChanged")
import("player.events.SettingsChanged")
import("player.events.controls.Pick")
import("player.events.controls.Clear")
import("player.events.controls.Craft")
import("player.events.controls.Nothing")
import("gui.Tooltip")
import("gui.toolbar.content.sections.section.content.table.Slot")
import("gui.toolbar.content.sections.section.content.table.slots.item.ItemButton")
import("gui.toolbar.content.sections.section.content.table.slots.item.DimOverlay")
import("gui.toolbar.content.sections.section.content.table.slots.item.QualityOverlay")

---@class ItemSlot : Slot
---@field private __messages table<string, string>
---@field private __tooltip table<string, string>
ItemSlot = Slot:extendAs("gui.toolbar.content.sections.section.content.table.slots.item.ItemSlot")

---@param parent Component
---@param item Item
function ItemSlot:create(parent, item)
    local instance = Slot.create(self, parent)
    ItemButton:create(instance, item, { "left", "middle", "right", "button-5" })
    QualityOverlay:create(instance, item:quality())
    instance:refresh()
    return instance
end

function ItemSlot:new(parent, root)
    local this = ItemSlot:super(Slot:new(parent, root))
    local eventBus = this:player():eventBus()
    eventBus:subscribeTo(CursorStackChanged, this)
    eventBus:subscribeTo(InventoryContentChanged, this)
    eventBus:subscribeTo(SettingsChanged, this)
    return this
end

function ItemSlot:refresh()
    self:refreshTooltip()
    self:refreshCount()
end

function ItemSlot:childrenClasses()
    return { ItemButton, QualityOverlay }
end

function ItemSlot:controls()
    return { Pick, Clear, Craft }
end

function ItemSlot:handleClick(click)
    self:handle(self:recognizeControl(click))
end

---@return Event
function ItemSlot:recognizeControl(click)
    if click:isLeft() and not click:withModifier() then
        return Pick:new()
    elseif click:isMiddle() and not click:withModifier() then
        return Clear:new()
    else
        return self:recognizeCraftControl(click)
    end
end

---@param click Click
---@return Craft
function ItemSlot:recognizeCraftControl(click)
    if click:isLeft() and click:withOnlyCtrl() then
        return Craft:one()
    elseif (click:isRight() or click:isButton5()) and click:withOnlyCtrl() then
        return Craft:five()
    elseif (click:isRight() or click:isButton5()) and click:withOnlyAlt() then
        return Craft:stackHalf()
    elseif click:isLeft() and click:withOnlyAlt() then
        return Craft:stack()
    elseif (click:isRight() or click:isButton5()) and (click:withOnlyShift() or (click:withCtrl() and click:withAlt() and not click:withShift())) then
        return Craft:allHalf()
    elseif click:isLeft() and (click:withOnlyShift() or (click:withCtrl() and click:withAlt() and not click:withShift())) then
        return Craft:all()
    else
        return Nothing:new()
    end
end

---@private
---@param event Event
function ItemSlot:handle(event)
    if event:isInstanceOf(CursorStackChanged) then
        self:toggleHighlight()
    elseif event:isInstanceOf(InventoryContentChanged) then
        self:refreshCount()
    elseif event:isInstanceOf(SettingsChanged) then
        self:refreshTooltip()
    elseif event:isInstanceOf(Pick) then
        self:handlePick()
    elseif event:isInstanceOf(Clear) then
        self:handleClear()
    elseif event:isInstanceOf(Craft) then
        self:handleCraft(event)
    end
end

---@private
function ItemSlot:handlePick()
    self:player():inventory():pick(self:item())
    self:rememberPick()
    self:presentSuccess()
end

---@private
function ItemSlot:handleClear()
    self:clear()
    self:presentSuccess()
end

---@param craft Craft
function ItemSlot:handleCraft(craft)
    if not self:luaPlayer().character then
        self:presentFailure(ItemSlot.__messages.noCharacterToCraft)
    elseif not self:hasRecipe() then
        self:presentFailure(ItemSlot.__messages.notCraftable)
    else
        local recipe = self:recipe()
        if not recipe.enabled then
            self:presentFailure(ItemSlot.__messages.notResearched)
        elseif not self:isManuallyCraftable(recipe) then
        elseif self:luaPlayer().get_craftable_count(recipe) == 0 then
            self:presentFailure(ItemSlot.__messages.notEnoughIngredients)
        else
            local requestedCraftCount = self:calculateCraftCount(craft)
            if requestedCraftCount then
                local startedCount = self:luaPlayer().begin_crafting { count = requestedCraftCount, recipe = recipe.name }
                self:presentSuccess(startedCount)
            else
                self:presentFailure()
            end
        end
    end
end

---@private
---@return boolean
function ItemSlot:hasRecipe()
    return self:recipe() ~= nil
end

---@private
---@return LuaRecipe
function ItemSlot:recipe()
    local recipePrototype = self:recipePrototype()
    if recipePrototype then
        return self:luaPlayer().force.recipes[recipePrototype.name]
    end
end

---@private
---@return LuaRecipePrototype
function ItemSlot:recipePrototype()
    local recipes = prototypes.get_recipe_filtered(
            { {
                  filter = "has-product-item",
                  elem_filters = { { filter = "name", name = self:item():name() } }
              } })
    for _, recipe in pairs(recipes) do
        if not recipe.name:match("recycling$") then
            return recipe
        end
    end
    return nil
end

---@private
---@param craft Craft
function ItemSlot:calculateCraftCount(craft)
    if craft:isOne() then
        return 1
    elseif craft:isFive() then
        return 5
    elseif craft:isStackHalf() then
        return self:itemPrototype().stack_size / 2
    elseif craft:isStack() then
        return self:itemPrototype().stack_size
    elseif craft:isAllHalf() then
        return self:luaPlayer().get_craftable_count(self:recipe()) / 2
    elseif craft:isAll() then
        return self:luaPlayer().get_craftable_count(self:recipe())
    else
        error("Unknown craft request")
    end
end

---@private
---@return LuaItemPrototype
function ItemSlot:itemPrototype()
    return prototypes.item[self:item():name()]
end

---@private
---@param message string | nil
function ItemSlot:presentSuccess(message)
    self:luaPlayer().play_sound { path = "utility/inventory_click" }
    if message then
        self:luaPlayer().create_local_flying_text { text = message, create_at_cursor = true }
    end
end

---@private
---@param message string | nil
function ItemSlot:presentFailure(message)
    self:luaPlayer().play_sound { path = "utility/cannot_build" }
    if message then
        self:luaPlayer().create_local_flying_text { text = message, create_at_cursor = true }
    end
end

---@private
function ItemSlot:toggleHighlight()
    local cursor = self:player():cursor()
    if cursor:holdsItem() and cursor:item():equals(self:item()) then
        self:button():select()
    else
        self:button():unselect()
    end
end

---@private
function ItemSlot:refreshCount()
    local count = self:player():inventory():count(self:item())
    ---@type Cursor
    local cursor = self:player():cursor()
    if cursor:holdsStack() and cursor:holdsItem() and cursor:item():equals(self:item()) then
        count = count + cursor:stackCount()
    end
    self:button():root().number = count > 0 and count or nil
end

---@private
---@return ItemButton
function ItemSlot:button()
    return self:childOfType(ItemButton)
end

function ItemSlot:thing()
    return self:item()
end

---@private
---@return Item
function ItemSlot:item()
    return self:button():item()
end

---@private
---@return string
function ItemSlot:refreshTooltip()
    self:button():setTooltip(self:tooltip():text())
end

---@private
---@return Tooltip
function ItemSlot:tooltip()
    if not self:luaPlayer().character then
        return Tooltip:new()
    elseif not self:hasRecipe() then
        return ItemSlot.__tooltip.notCraftable
    else
        local recipe = self:recipe()
        if not recipe.enabled then
            return ItemSlot.__tooltip.notResearched
        elseif not self:isManuallyCraftable(recipe) then
            return ItemSlot.__tooltip.notManuallyCraftable
        else
            local craftingSpeed = (self:luaPlayer().character_crafting_speed_modifier + 1) * (self:luaPlayer().force.manual_crafting_speed_modifier + 1)
            local craftingTime = recipe.energy / craftingSpeed

            local tooltip = Tooltip:new():appendLabelWithNumberValue("Crafting time", craftingTime, "s")
            if self:luaPlayer().mod_settings["show-controls-in-the-tooltip"].value then
                tooltip:appendNewLine():append(ItemSlot.__tooltip.controls:text())
            end
            return tooltip
        end
    end
end

---@param recipe LuaRecipe
function ItemSlot:isManuallyCraftable(recipe)
    return self:luaPlayer().character.prototype.crafting_categories[recipe.category]
end

ItemSlot.__messages = {
    noCharacterToCraft = "No character to craft",
    notCraftable = "Not craftable",
    notResearched = "Not researched",
    notManuallyCraftable = "Not manually craftable",
    notEnoughIngredients = "Not enough ingredients"
}

ItemSlot.__tooltip = {
    noCharacterToCraft = Tooltip:new():appendLabel(ItemSlot.__messages.noCharacterToCraft),
    notCraftable = Tooltip:new():appendLabel(ItemSlot.__messages.notCraftable),
    notResearched = Tooltip:new():appendLabel(ItemSlot.__messages.notResearched),
    notManuallyCraftable = Tooltip:new():appendLabel(ItemSlot.__messages.notManuallyCraftable),

    controls = Tooltip:new()
                      :appendControl("Ctrl + Left Click", "Craft 1"):appendNewLine()
                      :appendControl("Ctrl + Right Click", "Craft 5"):appendNewLine()
                      :appendControl("Alt + (Right Click | Button5)", "Craft Stack / 2"):appendNewLine()
                      :appendControl("Alt + Left Click", "Craft Stack"):appendNewLine()
                      :appendControl("(Ctrl + Alt | Shift) + (Right Click | Button5)", "Craft All / 2"):appendNewLine()
                      :appendControl("(Ctrl + Alt | Shift) + Left Click", "Craft All"):appendNewLine()
                      :append("(hide controls in settings)")
}
