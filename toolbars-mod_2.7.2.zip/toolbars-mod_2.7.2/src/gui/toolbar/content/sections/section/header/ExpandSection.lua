import("gui.toolbar.content.sections.section.header.SectionHeaderButton")
import("gui.toolbar.content.sections.section.header.CollapseSection")

---@class ExpandSection : SectionHeaderButton
ExpandSection = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.Expand")

function ExpandSection:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_expand",
        style = "toolbar_content_sections_section_header_expand" })
end

function ExpandSection:new(parent, root)
    return ExpandSection:super(SectionHeaderButton:new(parent, root))
end

function ExpandSection:handleClick(click)
    if click:isLeft() then
        self:section():expand()
        self:replaceWith(CollapseSection:create(self:parent()))
    end
end
