import("player.Player")
import("Item")
import("gui.Component")
import("gui.toolbar.Toolbar")
import("gui.toolbar.content.sections.section.content.table.Table")
import("gui.toolbar.content.sections.section.content.table.SlotHistory")

---@class Slot : Component
---@field private _player_index number
---@field private _history SlotHistory
Slot = Component:extendAs("gui.toolbar.content.sections.section.content.table.Slot")

function Slot.create(class, parent)
    local instance = Component.create(class, parent, {
        type = "empty-widget",
        style = "toolbar_content_sections_section_content_table_row_slot"
    })
    return instance
end

---@protected
---@return Slot
---@param root LuaGuiElement
function Slot:new(parent, root)
    local this = Slot:super(Component:new(parent, root))
    this._history = SlotHistory:getInstanceFor(this:root().player_index)
    return this
end

---@protected
---@param thing Thing
---@return boolean
function Slot:wasMoved(thing)
    return self._history:hasLastPickedSlot() and self._history:lastPickedSlot():isValid()
            and self._history:lastPickedSlot():thing():equals(thing)
end

---@protected
function Slot:move()
    self._history:lastPickedSlot():clear()
end

---@protected
function Slot:rememberPick()
    self._history:rememberPick(self)
end

---@protected
function Slot:forgetPick()
    self._history:forgetPick()
end

---@protected
function Slot:clear()
    local empty = EmptySlot:create(self:parent())
    self:replaceWith(empty)
    empty:adjustToolbarSize()
end

---@protected
function Slot:adjustToolbarSize()
    self:findAncestor(Toolbar):adjustSize()
end

---@private
---@return number
function Slot:index()
    return self:root().get_index_in_parent()
end

---@protected
---@return boolean
function Slot:isOccupied()
    return self:thing() ~= nil
end

---@protected
---@return string
function Slot:thing()
    error("Not implemented")
end
