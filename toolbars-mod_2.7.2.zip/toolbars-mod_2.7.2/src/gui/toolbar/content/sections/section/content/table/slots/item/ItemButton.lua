import("gui.Component")
import("Item")

---@class ItemButton : Component
---@field private _item Item
ItemButton = Component:extendAs("gui.toolbar.content.sections.section.content.table.slots.item.ItemButton")

---@param parent Component
---@param item Item
---@param mouse_button_filter string[]
---@return ItemButton
function ItemButton:create(parent, item, mouse_button_filter)
    Component.create(self, parent, {
        type = "sprite-button",
        elem_tooltip = { type = "item-with-quality", name = item:name(), quality = item:quality() },
        sprite = "item/" .. assert(item:name()),
        style = "toolbar_content_sections_section_content_table_row_slot_button_item",
        mouse_button_filter = mouse_button_filter,
        raise_hover_events = true
    })
end

function ItemButton:new(parent, root)
    local this = ItemButton:super(Component:new(parent, root))
    --todo migration: remove after several releases from 2.7.0
    this:root().raise_hover_events = true
    --todo migration: remove after several releases from 2.0.9
    if this:root().tags.quality then
        local tags = this:root().tags
        this:root().elem_tooltip = { type = "item-with-quality", name = this:root().elem_tooltip.name, quality = tags.quality }
        tags.quality = nil
        this:root().tags = tags
    end
    this._item = Item:new(this:root().elem_tooltip.name, this:root().elem_tooltip.quality)
end

---@public
---@return Item
function ItemButton:item()
    return self._item
end

---@param text string
function ItemButton:setTooltip(text)
    self:root().tooltip = text
end

function ItemButton:select()
    self:root().style = "toolbar_content_sections_section_content_table_row_slot_button_item_selected"
end

function ItemButton:unselect()
    self:root().style = "toolbar_content_sections_section_content_table_row_slot_button_item"
end
