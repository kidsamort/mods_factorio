import("gui.Component")

---@class SectionName : Component
SectionName = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.Name")

function SectionName:create(parent)
    local instance = Component.create(self, parent, {
        type = "textfield",
        style = "toolbar_content_sections_section_header_name" })
    instance:root().lose_focus_on_confirm = true
    return instance
end

function SectionName:new(parent, root)
    return SectionName:super(Component:new(parent, root))
end

---@public
function SectionName:focus()
    self:root().focus()
end

function SectionName:lock()
    self:root().enabled = false
    self:root().ignored_by_interaction = true
end

function SectionName:unlock()
    self:root().enabled = true
    self:root().ignored_by_interaction = false
end

---@public
---@return string
function SectionName:text()
    return self:root().text
end
