import("gui.toolbar.content.sections.section.header.SectionHeaderButton")

---@class ConfirmDeleteSection : SectionHeaderButton
ConfirmDeleteSection = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.ConfirmDelete")

function ConfirmDeleteSection:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_confirm",
        style = "toolbar_content_sections_section_header_confirmDelete" })
end

function ConfirmDeleteSection:new(parent, root)
    return ConfirmDeleteSection:super(SectionHeaderButton:new(parent, root))
end

function ConfirmDeleteSection:handleClick(click)
    if click:isLeft() then
        self:section():delete()
    end
end
