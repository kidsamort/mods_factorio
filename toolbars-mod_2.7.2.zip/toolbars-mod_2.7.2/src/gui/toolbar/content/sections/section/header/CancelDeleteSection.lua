import("gui.toolbar.content.sections.section.header.SectionHeaderButton")

---@class CancelDeleteSection : SectionHeaderButton
CancelDeleteSection = SectionHeaderButton:extendAs("gui.toolbar.content.sections.section.header.CancelDelete")

function CancelDeleteSection:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_cancel",
        style = "toolbar_content_sections_section_header_cancelDelete" })
end

function CancelDeleteSection:new(parent, root)
    return CancelDeleteSection:super(SectionHeaderButton:new(parent, root))
end

function CancelDeleteSection:handleClick(click)
    if click:isLeft() then
        self:header():cancelDeletion()
    end
end
