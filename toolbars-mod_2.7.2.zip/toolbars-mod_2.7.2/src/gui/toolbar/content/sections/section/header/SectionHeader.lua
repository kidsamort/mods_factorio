import("gui.Component")
import("gui.toolbar.Toolbar")
import("gui.toolbar.content.sections.section.header.MoveDown")
import("gui.toolbar.content.sections.section.header.MoveUp")
import("gui.toolbar.content.sections.section.header.ExpandSection")
import("gui.toolbar.content.sections.section.header.CollapseSection")
import("gui.toolbar.content.sections.section.header.DeleteSection")
import("gui.toolbar.content.sections.section.header.CancelDeleteSection")
import("gui.toolbar.content.sections.section.header.ConfirmDeleteSection")
import("gui.toolbar.content.sections.section.header.SectionName")

---@class SectionHeader : Component
SectionHeader = Component:extendAs("gui.toolbar.content.sections.section.header.Header")

function SectionHeader:create(parent)
    local instance = Component.create(self, parent, {
        type = "flow",
        direction = "horizontal",
        style = "toolbar_content_sections_section_header" })
    instance:root().style.bottom_margin = 1

    MoveDown:create(instance)
    MoveUp:create(instance)
    SectionName:create(instance):focus()
    CollapseSection:create(instance)
    DeleteSection:create(instance)

    return instance
end

function SectionHeader:new(parent, root)
    return SectionHeader:super(Component:new(parent, root))
end

function SectionHeader:childrenClasses()
    return {
        MoveDown, MoveUp,
        CollapseSection, ExpandSection,
        SectionName,
        DeleteSection, ConfirmDeleteSection, CancelDeleteSection }
end

---@public
function SectionHeader:askForDeletion()
    self:childOfType(DeleteSection):delete()
    ConfirmDeleteSection:create(self)
    CancelDeleteSection:create(self)
end

---@public
function SectionHeader:cancelDeletion()
    self:childOfType(CancelDeleteSection):delete()
    self:childOfType(ConfirmDeleteSection):delete()
    DeleteSection:create(self)
end

function SectionHeader:lock()
    if self:isOnlyOne() and not self:hasName() then
        self:hide()
    end
    Component.lock(self)
end

---@private
---@return boolean
function SectionHeader:isOnlyOne()
    return self:toolbar():sectionsCount() == 1
end

---@private
---@return boolean
function SectionHeader:hasName()
    return self:name() ~= ""
end

function SectionHeader:unlock()
    self:show()
    Component.unlock(self)
end

---@private
---@return Toolbar
function SectionHeader:toolbar()
    return self:findAncestor(Toolbar)
end

---@public
---@return string
function SectionHeader:name()
    return self:childOfType(SectionName):text()
end
