import("gui.Component")
import("gui.toolbar.content.sections.section.content.table.Row")

---@class Table : Component
Table = Component:extendAs("gui.toolbar.content.sections.section.content.table.Table")

function Table:create(parent)
    return Component.create(self, parent, {
        type = "frame",
        direction = "vertical",
        style = "toolbar_content_sections_section_content_table" })
end

function Table:new(parent, root)
    return Table:super(Component:new(parent, root))
end

function Table:childrenClasses()
    return { Row }
end

---@public
---@param columns number
---@param minimumRows number
---@param bottomEmptyRows number
function Table:resize(columns, minimumRows, bottomEmptyRows)
    self:setRows(minimumRows, bottomEmptyRows)
    self:setColumns(columns)
end

---@private
---@param minimumRows number
---@param bottomEmptyRows number
function Table:setRows(minimumRows, bottomEmptyRows)
    self:trimHeight()
    self:fill(minimumRows, bottomEmptyRows)
end

---@private
function Table:trimHeight()
    local lastOccupiedRowIndex = self:lastOccupiedRowIndex()
    for _, row in ipairs(self:rows()) do
        if row:index() > lastOccupiedRowIndex then
            row:delete()
        end
    end
end

---@private
---@return number
function Table:lastOccupiedRowIndex()
    local lastOccupiedRowIndex = 0
    for _, row in ipairs(self:rows()) do
        if row:isOccupied() then
            lastOccupiedRowIndex = math.max(lastOccupiedRowIndex, row:index())
        end
    end
    return lastOccupiedRowIndex
end

---@private
---@param minimumRows number
---@param bottomEmptyRows number
function Table:fill(minimumRows, bottomEmptyRows)
    local missingRows = minimumRows - self:rowsCount()
    local rowsToAdd = missingRows >= bottomEmptyRows and missingRows or bottomEmptyRows
    local i = 0
    while i < rowsToAdd do
        Row:create(self)
        i = i + 1
    end
end

---@private
---@param columns number
function Table:setColumns(columns)
    for _, row in ipairs(self:rows()) do
        row:setColumns(columns)
    end
end

---@public
---@return number
function Table:lastOccupiedColumnIndex()
    local rows = self:rows()
    local lastOccupiedColumn = 0
    for _, row in ipairs(rows) do
        lastOccupiedColumn = math.max(lastOccupiedColumn, row:lastOccupiedColumn())
    end
    return lastOccupiedColumn
end

---@public
---@return number
function Table:width()
    local firstRow = self:rows()[1]
    if firstRow then
        return firstRow:width()
    else
        return 4 * 40
    end
end

---@private
---@return number
function Table:rowsCount()
    return #self:root().children
end

---@private
---@return Row[]
function Table:rows()
    return self:children()
end
