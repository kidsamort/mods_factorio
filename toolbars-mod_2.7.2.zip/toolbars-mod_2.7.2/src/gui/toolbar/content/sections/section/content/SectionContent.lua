import("gui.Component")
import("gui.toolbar.content.sections.section.content.table.Table")

---@class SectionContent : Component
SectionContent = Component:extendAs("gui.toolbar.content.sections.section.content.Content")

function SectionContent:create(parent)
    local instance = Component.create(self, parent, {
        type = "flow",
        direction = "vertical",
        style = "toolbar_content_sections_section_content" })
    Table:create(instance)
    return instance
end

---@public
---@return SectionContent
---@param root LuaGuiElement
function SectionContent:new(parent, root)
    return SectionContent:super(Component:new(parent, root))
end

function SectionContent:childrenClasses()
    return { Table }
end

---@public
---@return number
function SectionContent:width()
    return self:table():width()
end

---@public
---@return Table
function SectionContent:table()
    return self:childOfType(Table)
end
