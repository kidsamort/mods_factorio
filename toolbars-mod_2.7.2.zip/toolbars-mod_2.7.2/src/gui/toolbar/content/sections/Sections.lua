import("gui.Component")
import("gui.toolbar.content.sections.section.Section")

---@class Sections : Component
Sections = Component:extendAs("gui.toolbar.content.sections.Sections")

function Sections:create(parent)
    local instance = Component.create(self, parent,  {
        type = "flow",
        direction = "vertical",
        style = "toolbar_content_sections" })
    instance:addSection()
    return instance
end

---@public
---@return Sections
---@param root LuaGuiElement
function Sections:new(parent, root)
    return Sections:super(Component:new(parent, root))
end

function Sections:childrenClasses()
    return { Section }
end

---@public
function Sections:addSection()
    Section:create(self)
end

---@public
---@return number
function Sections:count()
    return #self:root().children
end

function Sections:width()
    local firstSection = self:list()[1]
    if firstSection then
        return firstSection:width()
    else
        return 4 * 40
    end
end

---@public
---@return Section[]
function Sections:list()
    return self:childrenOfType(Section)
end
