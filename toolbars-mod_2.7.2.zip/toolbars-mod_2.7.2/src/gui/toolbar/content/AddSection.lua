import("gui.Component")
import("gui.toolbar.Toolbar")

---@class AddSection : Component
AddSection = Component:extendAs("gui.toolbar.content.AddSection")

function AddSection:create(parent)
    local instance = Component.create(self, parent, {
        type = "button",
        sprite = "toolbars-mod_add-section",
        style = "toolbar_content_addSection" })
    instance:root().caption = "Add section"
    return instance
end

function AddSection:new(parent, root)
    return AddSection:super(Component:new(parent, root))
end

function AddSection:handleClick(click)
    if click:isLeft() then
        self:findAncestor(Toolbar):addSection()
    end
end

function AddSection:lock()
    self:hide()
end

function AddSection:unlock()
    self:show()
end
