import("gui.Component")
import("gui.toolbar.Toolbar")
import("gui.toolbar.header.ToolbarHeader")

---@class ToolbarHeaderButton : Component
ToolbarHeaderButton = Component:extendAs("gui.toolbar.header.Button")

function ToolbarHeaderButton:new(parent, root)
    return ToolbarHeaderButton:super(Component:new(parent, root))
end

---@protected
---@return Toolbar
function ToolbarHeaderButton:toolbar()
    return self:findAncestor(Toolbar)
end

---@protected
---@return ToolbarHeader
function ToolbarHeaderButton:header()
    return self:findAncestor(ToolbarHeader)
end

function ToolbarHeaderButton:lock()
    self:root().style.size = 16
end

function ToolbarHeaderButton:unlock()
    self:root().style.size = 20
end

---@protected
---@return boolean
function ToolbarHeaderButton:isLocked()
    return self:root().style.maximal_width == 16
end
