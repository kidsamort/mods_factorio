import("gui.Component")
import("gui.toolbar.Toolbar")
import("gui.toolbar.header.Lock")
import("gui.toolbar.header.Unlock")
import("gui.toolbar.header.CollapseToolbar")
import("gui.toolbar.header.ExpandToolbar")
import("gui.toolbar.header.DeleteToolbar")
import("gui.toolbar.header.CancelDeleteToolbar")
import("gui.toolbar.header.ConfirmDeleteToolbar")

---@class ToolbarHeader : Component
ToolbarHeader = Component:extendAs("gui.toolbar.header.Header")

function ToolbarHeader:create(parent)
    local instance = Component.create(self, parent, {
        type = "flow",
        direction = "horizontal",
        style = "toolbar_header" })
    Lock:create(instance)
    local drag = instance:root().add {
        type = "empty-widget",
        style = "toolbar_drag" }
    drag.drag_target = instance:findAncestor(Toolbar):root()

    CollapseToolbar:create(instance)
    DeleteToolbar:create(instance)
    return instance
end

function ToolbarHeader:new(parent, root)
    return ToolbarHeader:super(Component:new(parent, root))
end

function ToolbarHeader:childrenClasses()
    return { Lock, Unlock,
             CollapseToolbar, ExpandToolbar,
             DeleteToolbar, CancelDeleteToolbar, ConfirmDeleteToolbar }
end

function ToolbarHeader:askForDeletion()
    self:childOfType(DeleteToolbar):delete()
    ConfirmDeleteToolbar:create(self)
    CancelDeleteToolbar:create(self)
end

function ToolbarHeader:cancelDeletion()
    self:childOfType(CancelDeleteToolbar):delete()
    self:childOfType(ConfirmDeleteToolbar):delete()
    local deleteToolbar = DeleteToolbar:create(self)
    if self:isLocked() then
        deleteToolbar:lock()
    end
end

function ToolbarHeader:isLocked()
    return #self:childrenOfType(Unlock) > 0
end
