import("gui.toolbar.header.ToolbarHeaderButton")

---@class ConfirmDeleteToolbar : ToolbarHeaderButton
ConfirmDeleteToolbar = ToolbarHeaderButton:extendAs("gui.toolbar.header.ConfirmDelete")

function ConfirmDeleteToolbar:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_confirm",
        style = "toolbar_header_confirmDelete" })
end

function ConfirmDeleteToolbar:new(parent, root)
    return ConfirmDeleteToolbar:super(ToolbarHeaderButton:new(parent, root))
end

function ConfirmDeleteToolbar:handleClick(click)
    if click:isLeft() then
        self:toolbar():delete()
    end
end
