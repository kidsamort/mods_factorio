import("gui.toolbar.header.ToolbarHeaderButton")
import("gui.toolbar.header.Lock")

---@class Unlock : ToolbarHeaderButton
Unlock = ToolbarHeaderButton:extendAs("gui.toolbar.header.Unlock")

function Unlock:create(parent)
    local instance = Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_padlock-closed",
        style = "toolbar_header_unlock" })
    instance:lock()
    return instance
end

function Unlock:new(parent, root)
    return Unlock:super(ToolbarHeaderButton:new(parent, root))
end

function Unlock:handleClick(click)
    if click:isLeft() then
        self:toolbar():unlock()
    end
end

function Unlock:unlock()
    self:replaceWith(Lock:create(self:parent()))
end
