import("gui.toolbar.header.ToolbarHeaderButton")
import("gui.toolbar.header.CollapseToolbar")

---@class ExpandToolbar : ToolbarHeaderButton
ExpandToolbar = ToolbarHeaderButton:extendAs("gui.toolbar.header.Expand")

function ExpandToolbar:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_expand",
        style = "toolbar_header_expand" })
end

function ExpandToolbar:new(parent, root)
    return ExpandToolbar:super(ToolbarHeaderButton:new(parent, root))
end

function ExpandToolbar:handleClick(click)
    if click:isLeft() then
        self:toolbar():expand()
        local collapse = CollapseToolbar:create(self:parent())
        if self:isLocked() then collapse:lock() end
        self:replaceWith(collapse)
    end
end
