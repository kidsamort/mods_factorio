import("gui.toolbar.header.ToolbarHeaderButton")

---@class CollapseToolbar : ToolbarHeaderButton
CollapseToolbar = ToolbarHeaderButton:extendAs("gui.toolbar.header.Collapse")

function CollapseToolbar:create(parent)
    return Component.create(self, parent, {
        type = "sprite-button",
        sprite = "toolbars-mod_collapse",
        style = "toolbar_header_collapse" })
end

function CollapseToolbar:new(parent, root)
    return CollapseToolbar:super(ToolbarHeaderButton:new(parent, root))
end

function CollapseToolbar:handleClick(click)
    if click:isLeft() then
        self:toolbar():collapse()
        local expand = ExpandToolbar:create(self:parent())
        if self:isLocked() then
            expand:lock()
        end
        self:replaceWith(expand)
    end
end
