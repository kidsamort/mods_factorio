import("gui.events.LocationChanged")
import("gui.Component")
import("gui.toolbar.header.ToolbarHeader")
import("gui.toolbar.header.Unlock")
import("gui.toolbar.content.ToolbarContent")
import("gui.toolbar.content.sections.Sections")
import("gui.toolbar.content.sections.section.Section")
import("gui.toolbar.content.sections.section.content.table.Table")

---@class Toolbar : Component
Toolbar = Component:extendAs("gui.toolbar.Toolbar")

function Toolbar:create(parent)
    local instance = Component.create(self, parent, {
        type = "frame",
        direction = "vertical",
        style = "toolbar" })
    ToolbarHeader:create(instance)
    ToolbarContent:create(instance)
    instance:adjustSize()
    return instance
end

function Toolbar:new(parent, root)
    return Toolbar:super(Component:new(parent, root))
end

function Toolbar:childrenClasses()
    return { ToolbarHeader, ToolbarContent }
end

---@private
---@return boolean
function Toolbar:isLocked()
    return self:childOfType(ToolbarHeader):childOfType(Unlock) ~= nil
end

function Toolbar:handleChange(changedEvent)
    if self:isOriginOf(changedEvent) then
        if changedEvent:isInstanceOf(LocationChanged) then
            self:keepWithinTheScreen()
            self:turnOffCenteringOnScreen()
        end
    else
        Component.handleChange(self, changedEvent)
    end
end

---@private
function Toolbar:keepWithinTheScreen()
    local location = self:location()
    if location.x < 0 then
        location.x = 0
    end
    if location.y < 0 then
        location.y = 0
    end
    self:setLocation(location)
end

---@private
---@return GuiLocation
function Toolbar:location()
    return self:root().location
end

---@private
---@param location GuiLocation
function Toolbar:setLocation(location)
    self:root().location = location
end

---@private
function Toolbar:turnOffCenteringOnScreen()
    self:root().auto_center = false
end

---@public
function Toolbar:centerOnScreen()
    self:root().force_auto_center()
end

---@public
function Toolbar:collapse()
    self:content():hide()
end

---@public
function Toolbar:expand()
    self:content():show()
end

---@public
function Toolbar:addSection()
    self:content():sections():addSection()
    self:adjustSize()
end

---@public
---@return number
function Toolbar:sectionsCount()
    return self:content():sections():count()
end

function Toolbar:lock()
    self:content():root().style = "toolbar_content"
    Component.lock(self)
    self:trim()
end

---@private
function Toolbar:trim()
    self:resize(1, 1, 0)
end

function Toolbar:unlock()
    Component.unlock(self)
    self:adjustSize()
end

---@public
function Toolbar:adjustSize()
    if not self:isLocked() then
        self:resize(4, 1, 1)
    end
end

---@private
---@param minimumColumns number
---@param minimumRows number
---@param bottomEmptyRows number
function Toolbar:resize(minimumColumns, minimumRows, bottomEmptyRows)
    local width = math.max(minimumColumns, self:lastOccupiedColumnIndex() + bottomEmptyRows)
    self:resizeTables(width, minimumRows, bottomEmptyRows)
    self:freezeWidth()
end

---@private
---@return number
function Toolbar:lastOccupiedColumnIndex()
    local lastOccupiedColumnIndex = 0
    for _, table in ipairs(self:tables()) do
        lastOccupiedColumnIndex = math.max(lastOccupiedColumnIndex, table:lastOccupiedColumnIndex())
    end
    return lastOccupiedColumnIndex
end

---@private
---@param columns number
---@param minimumRows number
---@param bottomEmptyRows number
function Toolbar:resizeTables(columns, minimumRows, bottomEmptyRows)
    for _, table in ipairs(self:tables()) do
        table:resize(columns, minimumRows, bottomEmptyRows)
    end
end

---@private
---@return Table[]
function Toolbar:tables()
    local tables = {}
    for _, section in pairs(self:content():sections():list()) do
        table.insert(tables, section:content():table())
    end
    return tables
end

---@private
function Toolbar:freezeWidth()
    self:header():root().style.minimal_width = self:width()
end

---@public
---@return number
function Toolbar:width()
    return self:content():width()
end

---@private
---@return ToolbarHeader
function Toolbar:header()
    return self:childOfType(ToolbarHeader)
end

---@private
---@return ToolbarContent
function Toolbar:content()
    return self:childOfType(ToolbarContent)
end
