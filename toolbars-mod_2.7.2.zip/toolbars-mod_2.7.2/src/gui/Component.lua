import("player.Player")

---@class Component : Object
---@field protected __class string
---@field private _player_index number
---@field private _parent Component
---@field private _root LuaGuiElement
---@field private _children Component[]
Component = Object:extendAs("gui.Component")

---[STATIC]
---Sets element.tags.className to value of self.__className to recognize it while searching
---@protected
---@generic C : Component
---@param class C
---@param parent Component
---@param addParameters LuaGuiElement.add_parameters
---@return C
function Component.create(class, parent, addParameters)
    local tags = addParameters.tags and addParameters.tags or {}
    tags.className = class:className()
    addParameters.tags = tags
    return class:new(parent, parent:root().add(addParameters))
end

---[STATIC]
---@protected
---@param parent Component
---@param root LuaGuiElement
---@return self
function Component:new(parent, root)
    local this = Component:super(Object:new())
    this._player_index = root.player_index
    this._parent = parent
    this._root = assert(root)
    this._children = {}
    if this._parent then
        this._parent:addChild(this)
    end
    return this
end

---@private
---@param child Component
function Component:addChild(child)
    table.insert(self._children, child)
end

---@private
---@param childToRemove Component
function Component:removeChild(childToRemove)
    for i, child in ipairs(self._children) do
        if child:root() == childToRemove:root() then
            table.remove(self._children, i)
        end
    end
end

---@public
---@param click Click
function Component:handleClick(click)
    local child = self:findChildContaining(click:element())
    if child then
        child:handleClick(click)
    end
end

---@public
---@param changedEvent ChangedEvent
function Component:handleChange(changedEvent)
    local child = self:findChildContaining(changedEvent:element())
    if child then
        child:handleChange(changedEvent)
    end
end

---@public
---@param hovered Hovered
function Component:handleHover(hovered)
    local child = self:findChildContaining(hovered:element())
    if child then
        child:handleHover(hovered)
    end
    self:registerControls()
end

---@private
function Component:registerControls()
    for _, control in ipairs(self:controls()) do
        self:player():eventBus():subscribeTo(control, self)
    end
end

---@public
---@param left Left
function Component:handleLeave(left)
    local child = self:findChildContaining(left:element())
    if child then
        child:handleLeave(left)
    end
    self:unregisterControls()
end

---@private
function Component:unregisterControls()
    for _, control in ipairs(self:controls()) do
        self:player():eventBus():unsubscribeFrom(control, self)
    end
end

---@public
function Component:lock()
    for _, child in ipairs(self:children()) do
        child:lock()
    end
end

---@public
function Component:unlock()
    for _, child in ipairs(self:children()) do
        child:unlock()
    end
end

---@return self[]
function Component:siblingsAndMe()
    return self:parent():childrenOfType(self:class())
end

---@generic T : Component
---@param class T
---@return T
function Component:childOfType(class)
    return self:childrenOfType(class)[1]
end

---@generic T : Component
---@param class T
---@return T[]
function Component:childrenOfType(class)
    local children = {}
    for _, child in ipairs(self:children()) do
        if child:isInstanceOf(class) then
            table.insert(children, child)
        end
    end
    return children
end

---@public
---@return Component[]
function Component:children()
    local children = {}
    for _, child in ipairs(self._children) do
        table.insert(children, child)
    end
    return children
end

---@public
function Component:load()
    local descendants = { self }
    while #descendants > 0 do
        ---@type Component
        local parent = table.remove(descendants)
        parent:loadChildren()
        for _, child in ipairs(parent:children()) do
            table.insert(descendants, child)
        end
    end
    self:refresh()
end

---@private
function Component:loadChildren()
    for _, childClass in ipairs(self:childrenClasses()) do
        for _, childRoot in ipairs(self:root().children) do
            if childClass:isRepresentedBy(childRoot) then
                childClass:new(self, childRoot)
            end
        end
    end
end

---@protected
---@return Component[]
function Component:childrenClasses()
    return {}
end

---@public
---@return Event[]
function Component:controls()
    return {}
end

---[STATIC]
---@public
---@param element LuaGuiElement
---@return boolean
function Component:isRepresentedBy(element)
    return element.tags and element.tags.className == self:className()
end

---@protected
function Component:refresh()
    for _, child in ipairs(self:children()) do
        child:refresh()
    end
end

---@generic T : Component
---@param class T
---@return T
function Component:findAncestor(class)
    if self:parent() == nil then
        error("No ancestor of class: " .. class:className())
    elseif self:isInstanceOf(class) then
        return self
    else
        return self:parent():findAncestor(class)
    end
end

---@protected
---@param replacement Component
function Component:replaceWith(replacement)
    self:parent():root().swap_children(self:index(), replacement:index())
    self:delete()
end

---@public
---@return boolean
function Component:isValid()
    return self:root().valid
end

---@public
function Component:show()
    self:root().visible = true
end

---@public
function Component:hide()
    self:root().visible = false
end

---@public
---@return boolean
function Component:isVisible()
    return self:root().visible
end

---@public
function Component:delete()
    self:deleteChildren()
    self:parent():removeChild(self)
    self:player():eventBus():unsubscribeFromAll(self)
    self:root().destroy()
end

function Component:deleteChildren()
    for _, child in ipairs(self:children()) do
        child:delete()
    end
end

---@protected
---@return number
function Component:index()
    return self:root().get_index_in_parent()
end

---@protected
---@return Component
function Component:parent()
    return self._parent
end

---@protected
---@return LuaGuiElement
function Component:parentElement()
    return self:root().parent
end

---@protected
---@return LuaGuiElement
function Component:root()
    return self._root
end

---@public
---@return boolean
---@param guiEvent GuiEvent
function Component:isOriginOf(guiEvent)
    return self:root() == guiEvent:element()
end

---@private
---@param element LuaGuiElement
---@return Component
function Component:findChildContaining(element)
    for _, child in ipairs(self:children()) do
        if child:contains(element) then
            return child
        end
    end
end

---@private
---@param element LuaGuiElement
---@return boolean
function Component:contains(element)
    if element.parent == nil then
        return false
    elseif self:root() == element then
        return true
    else
        return self:contains(element.parent)
    end
end

---@public
---@return Player
function Component:player()
    return Player:get(self._player_index)
end

---@protected
---@return LuaPlayer
function Component:luaPlayer()
    return game.players[self._player_index]
end
