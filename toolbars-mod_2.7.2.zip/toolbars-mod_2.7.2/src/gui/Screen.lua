import("gui.Component")
import("gui.toolbar.Toolbar")

---@class Screen : Component
Screen = Component:extendAs("player.Screen")

---@public
---@param luaPlayer LuaPlayer
function Screen:new(luaPlayer)
    return Screen:super(Component:new(nil, luaPlayer.gui.screen))
end

function Screen:childrenClasses()
    return { Toolbar }
end

---@private
---@return Toolbar[]
function Screen:toolbars()
    return self:children()
end

---@public
function Screen:createToolbar()
    return Toolbar:create(self):centerOnScreen()
end

---@public
function Screen:clear()
    for _, toolbar in ipairs(self:toolbars()) do
        toolbar:delete()
    end
end

---@public
function Screen:hide()
    for _, toolbar in ipairs(self:toolbars()) do
        toolbar:hide()
    end
end

---@public
function Screen:show()
    for _, toolbar in ipairs(self:toolbars()) do
        toolbar:show()
    end
end

---@private
---@param element LuaGuiElement
---@return boolean
function Screen:isRepresentedBy(element)
    return element.gui.screen == element
end
