---@class Tooltip : Object
---@field private _text string
Tooltip = Object:extendAs("Tooltip")

function Tooltip:new()
    local this = Tooltip:super(Object:new())
    this._text = ""
    return this
end

---@public
---@param control string
---@param action string
---@return self
function Tooltip:appendControl(control, action)
    return self:append(self:formatAsControl(control) .. ": " .. action)
end

---@private
---@param text string
---@return string
function Tooltip:formatAsControl(text)
    --used styles.control_input_shortcut_label
    return "[font=default-semibold][color=128,206,240]" .. text .. "[/color][/font]"
end

---@public
---@param label string
---@param value number
---@param unit string
---@return self
function Tooltip:appendLabelWithNumberValue(label, value, unit)
    return self:appendLabel(label .. ": "):appendNumber(value, 3):append(" "):append(unit)
end

---@public
---@return self
function Tooltip:appendLabel(label)
    return self:append(self:formatAsLabel(label))
end

---@private
---@param text string
---@return string
function Tooltip:formatAsLabel(text)
    return "[font=default-semibold][color=255,230,192]" .. text .. "[/color][/font]"
end

---@public
---@return self
function Tooltip:appendNumber(number, precision)
    return self:append(self:roundToString(number, precision))
end

---@private
---@param number number
---@param precision number
---@return string
function Tooltip:roundToString(number, precision)
    if ((number > 0 and number < 0.001) or number > 1000000) then
        return string.format("%1.1e", number)
    else
        return Tooltip:round(number, precision)
    end
end

---@private
---@param number number
---@param precision number
---@return number
function Tooltip:round(number, precision)
    local multiplied = 10 ^ (precision or 0)
    return math.floor(number * multiplied + 0.5) / multiplied
end

---@public
---@return self
function Tooltip:append(text)
    self._text = self._text .. text
    return self
end

---@public
---@return self
function Tooltip:appendNewLine()
    return self:append("\n")
end

---@public
---@return string
function Tooltip:text()
    return self._text
end
