import("gui.GuiEvent")

---@class Left : GuiEvent
Left = GuiEvent:extendAs("gui.events.Left")

---@param eventData EventData
function Left:new(eventData)
    return Left:super(GuiEvent:new(eventData))
end
