import("gui.GuiEvent")

---@class Hovered : GuiEvent
Hovered = GuiEvent:extendAs("gui.events.Hovered")

---@param eventData EventData
function Hovered:new(eventData)
    return Hovered:super(GuiEvent:new(eventData))
end
