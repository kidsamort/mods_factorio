import("gui.ChangedEvent")

---@class LocationChanged : ChangedEvent
LocationChanged = ChangedEvent:extendAs("gui.events.LocationChanged")

---@param eventData EventData
function LocationChanged:new(eventData)
    return LocationChanged:super(ChangedEvent:new(eventData))
end
