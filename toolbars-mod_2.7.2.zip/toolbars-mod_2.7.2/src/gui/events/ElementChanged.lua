import("gui.ChangedEvent")

---@class ElementChanged : ChangedEvent
ElementChanged = ChangedEvent:extendAs("gui.events.ElementChanged")

---@param eventData EventData
function ElementChanged:new(eventData)
    return ElementChanged:super(ChangedEvent:new(eventData))
end
