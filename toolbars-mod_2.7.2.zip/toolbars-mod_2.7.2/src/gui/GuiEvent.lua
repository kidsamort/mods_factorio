---@class GuiEvent
---@field _data EventData
GuiEvent = Object:extendAs("gui.Event")

---@param eventData EventData
function GuiEvent:new(eventData)
    local this = GuiEvent:super(Event:new())
    this._data = assert(eventData)
    return this
end

---@public
---@return string
function GuiEvent:modName()
    return self:element().get_mod()
end

---@public
---@return LuaGuiElement
function GuiEvent:element()
    return self:data().element
end

---@protected
---@return EventData
function GuiEvent:data()
    return self._data
end
