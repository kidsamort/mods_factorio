require('lang.load')

import("gui.events.Click")
import("gui.events.ElementChanged")
import("gui.events.LocationChanged")
import("gui.events.Hovered")
import("gui.events.Left")
import("player.Player")
import("player.events.controls.Pick")
import("player.events.CursorStackChanged")
import("player.events.InventoryChanged")
import("player.events.SettingsChanged")

Mod = {
    loaded = false,
    name = "toolbars-mod"
}

---@param event EventData
script.on_event(Mod.name .. "_create-toolbar", function(event)
    Player:get(event.player_index):createToolbar()
end)

---@param event EventData
script.on_event(defines.events.on_lua_shortcut, function(event)
    if event.prototype_name == Mod.name .. "_create-toolbar" then
        Player:get(event.player_index):createToolbar()
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_opened, function(event)
    if event.gui_type == defines.gui_type.entity and event.entity.name == "locomotive" then
        Player:get(event.player_index):hideToolbars()
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_closed, function(event)
    if event.gui_type == defines.gui_type.entity and event.entity.name == "locomotive" then
        Player:get(event.player_index):showToolbars()
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_click, function(event)
    local click = Click:new(event)
    if click:modName() == Mod.name then
        Player:get(event.player_index):handleClick(click)
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_elem_changed, function(event)
    local guiElementChanged = ElementChanged:new(event)
    if guiElementChanged:modName() == Mod.name then
        Player:get(event.player_index):handleChange(guiElementChanged)
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_location_changed, function(event)
    local guiLocationChanged = LocationChanged:new(event)
    if guiLocationChanged:modName() == Mod.name then
        Player:get(event.player_index):handleChange(guiLocationChanged)
    end
end)

---@param event EventData
script.on_event(defines.events.on_runtime_mod_setting_changed, function(event)
    if event.player_index
            and event.setting_type == "runtime-per-user"
            and event.setting == "show-controls-in-the-tooltip" then
        Player:get(event.player_index):handle(SettingsChanged:new())
    end
end)

---@param event EventData
script.on_event(defines.events.on_player_cursor_stack_changed, function(event)
    Player:get(event.player_index):handle(CursorStackChanged:new())
end)

---@param event EventData
script.on_event(defines.events.on_player_main_inventory_changed, function(event)
    Player:get(event.player_index):handle(InventoryChanged:new())
end)

---@param event EventData
script.on_event(defines.events.on_player_trash_inventory_changed, function(event)
    Player:get(event.player_index):handle(InventoryChanged:new())
end)

script.on_event(defines.events.on_player_controller_changed, function(event)
    Player:get(event.player_index):handle(InventoryChanged:new())
end)

-- seems that defines.events.on_player_changed_surface is triggered before new inventory is available
---@param event EventData
script.on_event(defines.events.on_player_toggled_map_editor, function(event)
    Player:get(event.player_index):handle(InventoryChanged:new())
end)

---@param event EventData
script.on_event(defines.events.on_gui_hover, function(event)
    local hovered = Hovered:new(event)
    if hovered:modName() == Mod.name then
        Player:get(event.player_index):handleHover(hovered)
    end
end)

---@param event EventData
script.on_event(defines.events.on_gui_leave, function(event)
    local left = Left:new(event)
    if left:modName() == Mod.name then
        Player:get(event.player_index):handleLeave(left)
    end
end)

---@param event EventData
script.on_event(Mod.name .. "_pipette", function(event)
    Player:get(event.player_index):handle(Pick:new())
end)

-----@param event EventData
--script.on_event(Mod.name .. "_clear", function(event)
--    Player:get(event.player_index):handle(Clear:new())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_1", function(event)
--    Player:get(event.player_index):handle(Craft:one())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_5", function(event)
--    Player:get(event.player_index):handle(Craft:five())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_stack_half", function(event)
--    Player:get(event.player_index):handle(Craft:stackHalf())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_stack", function(event)
--    Player:get(event.player_index):handle(Craft:stack())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_all_half", function(event)
--    Player:get(event.player_index):handle(Craft:allHalf())
--end)
--
-----@param event EventData
--script.on_event(Mod.name .. "_craft_all", function(event)
--    Player:get(event.player_index):handle(Craft:all())
--end)

---@param event EventData
script.on_nth_tick(5, function(event)
    if not Mod.loaded then
        Player:loadAllPlayers()
        Mod.loaded = true
    end
    for _, player in ipairs(Player:getAll()) do
        player:refreshInventory()
    end
end)

remote.add_interface(Mod.name, {
    loadPlayer = function(player_index)
        Player:reload(player_index)
    end,
    updateItemCount = function(player_index)
        for _ = 0, 100 do
            Player:get(player_index):handle(InventoryChanged:new())
            Player:get(player_index):refreshInventory()
        end
    end,
    refreshInventory = function(player_index)
        for _ = 0, 100 do
            Player:get(player_index):refreshInventory()
        end
    end,
    printCursorContent = function(player_index)
        local luaPlayer = game.players[player_index]
        luaPlayer.print("Holding:")
        if luaPlayer.cursor_record and luaPlayer.cursor_record.valid then
            local info = {
                type = luaPlayer.cursor_record.type,
                objectName = luaPlayer.cursor_record.object_name,
            }
            luaPlayer.print(serpent.block(info))
        end
        if luaPlayer.cursor_stack and luaPlayer.cursor_stack.valid_for_read then
            local info = {
                type = luaPlayer.cursor_stack.type,
                name = luaPlayer.cursor_stack.name,
                quality = luaPlayer.cursor_stack.quality.name,
                itemNumber = luaPlayer.cursor_stack.item_number,
                isSelectionTool = luaPlayer.cursor_stack.is_selection_tool,
                isItemWithEntityData = luaPlayer.cursor_stack.is_item_with_entity_data,
                isItemWithTags = luaPlayer.cursor_stack.is_item_with_tags
            }
            luaPlayer.print(serpent.block(info))
        end
    end
})
