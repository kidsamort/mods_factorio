data:extend {
    {
        type = "sprite",
        name = "toolbars-mod_add-section",
        filename = "__toolbars-mod__/_graphics/add-properties.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },

    {
        type = "sprite",
        name = "toolbars-mod_padlock-closed",
        filename = "__toolbars-mod__/_graphics/padlock-closed-white.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },
    {
        type = "sprite",
        name = "toolbars-mod_padlock-open",
        filename = "__toolbars-mod__/_graphics/padlock-open-white.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },

    {
        type = "sprite",
        name = "toolbars-mod_cancel",
        filename = "__toolbars-mod__/_graphics/cancel.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },
    {
        type = "sprite",
        name = "toolbars-mod_confirm",
        filename = "__toolbars-mod__/_graphics/confirm.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },

    {
        type = "sprite",
        name = "toolbars-mod_move-section-down",
        filename = "__toolbars-mod__/_graphics/move-down.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },
    {
        type = "sprite",
        name = "toolbars-mod_move-section-up",
        filename = "__toolbars-mod__/_graphics/move-up.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },

    {
        type = "sprite",
        name = "toolbars-mod_collapse",
        filename = "__toolbars-mod__/_graphics/collapse.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },
    {
        type = "sprite",
        name = "toolbars-mod_expand",
        filename = "__toolbars-mod__/_graphics/expand.png",
        priority = "extra-high-no-scale",
        size = 16,
        scale = 1,
        flags = { "gui-icon" }
    },
}
