# **Accumulator Walls**

A Wall equipped with an accumulator, storing power (1 MJ). More settings to customize your wall and store more energy.

Also compatible with:
- [Solar Walls](https://mods.factorio.com/mod/solar-walls)
- [Picker Dollies](https://mods.factorio.com/mod/PickerDollies)